package com.paywallet.core.states.common;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.AllArgsConstructor;

@Data
@Accessors(fluent = false, chain = true)
@AllArgsConstructor
@NoArgsConstructor
public class GeneralHttpResponse<T> {
    private Object id;
    private int status;
    private boolean isError;
    private String message;
    private T payload;
}
