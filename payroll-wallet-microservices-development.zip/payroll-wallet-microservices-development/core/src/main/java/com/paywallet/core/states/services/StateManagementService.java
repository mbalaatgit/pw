package com.paywallet.core.states.services;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.paywallet.core.states.entities.GroupJobState;
import com.paywallet.core.states.entities.JobState;
import com.paywallet.core.states.enums.JobStatusEnum;

@Service
public class StateManagementService<T> {

	@Value("${statemanagement.jobstate.expiry.hours}")
	private int hours;

	@Autowired
	private MongoTemplate mongoTemplate;

	public JobState<T> createSingleJobState(UUID jobId, String jobType) {
		JobState<T> jobState = getSingleJobStateDoc(jobId, jobType);
		mongoTemplate.save(jobState);
		return jobState;
	}

	public GroupJobState createGroupJobState(UUID groupId, UUID jobId, String jobType) {

		GroupJobState groupState = null;
		Optional<GroupJobState> groupById = getGroupJobState(groupId);
		Date now = new Date();
		if (groupById.isPresent()) {
			groupState = groupById.get();
			groupState.setLastModifiedDate(now);
		} else {
			groupState = new GroupJobState();
			groupState.setGroupId(groupId);
			groupState.setStatus(JobStatusEnum.PROCESSING);
			groupState.setJobs(new HashSet<>());
			groupState.setCreatedDate(now);
			groupState.setLastModifiedDate(now);
		}
		JobState<Object> jobState = (JobState<Object>) getSingleJobStateDoc(jobId, jobType);
		groupState.getJobs().add(jobState);
		mongoTemplate.save(groupState);
		return groupState;
	}

	public JobState<T> updateSingleJobState(UUID jobId, T payload, JobStatusEnum status) {
		JobState<T> jobState = null;
		Optional<JobState<T>> jobstateOpt = getJobState(jobId);
		if (jobstateOpt.isPresent()) {
			jobState = jobstateOpt.get();
			jobState.setJobId(jobId);
			jobState.setPayload(payload);
			jobState.setStatus(status);
			jobState.setLastModifiedDate(new Date());
			mongoTemplate.save(jobState);
		}
		return jobState;
	}

	public void updateJobStatusInGroup(UUID groupId, UUID jobId, T payload, JobStatusEnum status) {
		Optional<GroupJobState> groupById = getGroupJobState(groupId);
		if (groupById.isPresent()) {
			GroupJobState groupState = groupById.get();
			Optional<JobState<Object>> jobStateOpt = groupState.getJobs().stream()
					.filter(x -> x.getJobId() != null && x.getJobId().equals(jobId)).findAny();
			if (jobStateOpt.isPresent()) {
				JobState<Object> jobState = jobStateOpt.get();
				jobState.setPayload(payload);
				jobState.setStatus(status);
				Date now = new Date();
				jobState.setLastModifiedDate(now);
				groupState.setLastModifiedDate(now);
				mongoTemplate.save(groupState);
			}
		}
	}

	public void updateGroupJobState(UUID groupId, JobStatusEnum status) {
		Optional<GroupJobState> groupById = getGroupJobState(groupId);
		if (groupById.isPresent()) {
			GroupJobState groupState = groupById.get();
			groupState.setStatus(status);
			Date now = new Date();
			groupState.setLastModifiedDate(now);
			mongoTemplate.save(groupState);
		}
	}

	public Optional<JobState<T>> getJobState(UUID jobId) {
		JobState<T> jobState = mongoTemplate.findById(jobId, JobState.class);
		return Optional.ofNullable(jobState);
	}

	public Optional<GroupJobState> getGroupJobState(UUID groupId) {
		GroupJobState groupState = mongoTemplate.findById(groupId, GroupJobState.class);
		return Optional.ofNullable(groupState);
	}

	public Optional<Set<JobState<Object>>> getJobsOfGroup(UUID groupId) {
		Optional<Set<JobState<Object>>> jobs = Optional.empty();
		Query query = new Query();
		query.fields().include("jobs");
		query.addCriteria(Criteria.where("groupId").is(groupId));
		GroupJobState groupState = mongoTemplate.findOne(query, GroupJobState.class);
		if (groupState != null) {
			jobs = Optional.ofNullable(groupState.getJobs());
		}
		return jobs;

	}

	private JobState<T> getSingleJobStateDoc(UUID jobId, String jobType) {
		JobState<T> jobState = new JobState<>();
		jobState.setJobId(jobId);
		jobState.setJobType(jobType);
		jobState.setStatus(JobStatusEnum.PROCESSING);
		Date now = new Date();
		jobState.setExpiryDate(getExpiryDate(now));
		jobState.setCreatedDate(now);
		jobState.setLastModifiedDate(now);
		return jobState;
	}

	private Date getExpiryDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR_OF_DAY, hours);
		return calendar.getTime();
	}
}
