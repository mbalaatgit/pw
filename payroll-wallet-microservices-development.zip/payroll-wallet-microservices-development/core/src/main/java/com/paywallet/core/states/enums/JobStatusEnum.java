package com.paywallet.core.states.enums;

public enum JobStatusEnum {
	PROCESSING, COMPLETED, ERROR
}
