package com.paywallet.core.states.entities;

import java.util.Date;
import java.util.UUID;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paywallet.core.states.enums.JobStatusEnum;

import lombok.Data;

@Data
@Document("JobState")
public class JobState<T> {

	@Id
	private UUID jobId;

	private String jobType;

	private JobStatusEnum status;

	private T payload;

	private Date expiryDate;

	private Date createdDate;

	private Date lastModifiedDate;
}
