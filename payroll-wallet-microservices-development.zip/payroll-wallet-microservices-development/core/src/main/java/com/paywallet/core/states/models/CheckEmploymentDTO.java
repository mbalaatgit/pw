package com.paywallet.core.states.models;

import lombok.Data;

@Data
public class CheckEmploymentDTO {
    private String PayrollId;
    private String PeriodToCover;
    private String processType;
    private String enableCQRS;
    private String contentType;
}
