package com.paywallet.core.states.models;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class ProviderConnectRequestDTO {
    @NotNull
    private String username;
    @NotNull
    private String password;
    @NotNull
    private String employerId;
    @NotNull
    private Boolean ignorePdStatus;
}