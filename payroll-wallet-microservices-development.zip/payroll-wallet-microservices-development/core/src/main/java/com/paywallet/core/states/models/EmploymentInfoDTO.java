package com.paywallet.core.states.models;
import lombok.Data;

@Data
public class EmploymentInfoDTO {
    private String ABANumForSalary;
    private String AcctNumForSalary;
    private String AveragePayPerPayPeriodForXMonths;
    private String DateOfHire;
    private String EmploymentStatus;
    private String EstimatedAnnualSalary;
    private String MaxSalaryInPayPeriod;
    private String MinSalaryInPayPeriod;
    private String SalaryFrequency;
}