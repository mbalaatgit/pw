package com.paywallet.core.states.models;

import java.util.Set;

import lombok.Data;

@Data
public class CheckEmploymentReturnDTO {
  private Set<EmployersDTO> Employers;
  private String enquiryStatus;
}
