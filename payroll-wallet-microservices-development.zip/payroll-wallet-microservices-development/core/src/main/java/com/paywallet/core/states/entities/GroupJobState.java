package com.paywallet.core.states.entities;

import java.util.Date;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paywallet.core.states.enums.JobStatusEnum;

import lombok.Data;

@Data
@Document("GroupJobState")
public class GroupJobState {

	@Id
	private UUID groupId;

	private JobStatusEnum status;

	private Set<JobState<Object>> jobs;

	private Date createdDate;

	private Date lastModifiedDate;
}
