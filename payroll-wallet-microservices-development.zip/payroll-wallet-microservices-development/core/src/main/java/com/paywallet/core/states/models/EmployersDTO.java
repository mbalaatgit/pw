package com.paywallet.core.states.models;

import lombok.Data;

@Data
public class EmployersDTO {
    private String Employer;
    private EmploymentInfoDTO EmploymentInfo;
    private String PeriodToCover;
    private String id;
    private String label;
    private String type;
}
