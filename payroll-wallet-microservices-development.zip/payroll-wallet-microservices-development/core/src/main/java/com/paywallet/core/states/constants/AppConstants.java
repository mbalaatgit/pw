package com.paywallet.core.states.constants;

public abstract class AppConstants {
	private AppConstants() {

	}

	public static final String ERROR = "error";
	public static final String TOKEN = "token";
	public static final String RESULT = "result";
	public static final String ERROR_MESSAGE = "errorMessage";
	public static final String STATUS_CODE = "statusCode";
	public static final String PROVIDER = "PROVIDER";
	public static final String OFFSET = "offset";
	public static final String LIMIT = "limit";
	public static final String ACCOUNT = "account";
	public static final String RESULTS = "results";
	public static final String USER = "user";
	public static final String SUCCESS = "SUCCESS";
}
