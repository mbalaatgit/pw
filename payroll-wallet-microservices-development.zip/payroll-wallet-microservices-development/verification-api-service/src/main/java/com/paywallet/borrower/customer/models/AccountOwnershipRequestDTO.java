package com.paywallet.borrower.customer.models;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@ApiModel
@EqualsAndHashCode(callSuper = false)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountOwnershipRequestDTO extends BaseRequestParamDTO {

	@ApiParam(readOnly = true, example = "GetAcctOwnershipandStatus", required = true)
	private String processType;

	@ApiParam(name = "FirstName", required = true)
	private String firstName;

	@ApiParam(name = "MiddleInitial", required = false)
	private String middleInitial;

	@ApiParam(name = "LastName", required = true)
	private String lastName;

	@ApiParam(name = "ABANumber", required = true)
	private String ABANumber;

	@ApiParam(name = "AcctNumber", required = true)
	private String acctNumber;
}
