package com.paywallet.borrower.customer.models;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class BaseRequestParamDTO {

	@ApiParam(readOnly = true, name = "Content-Type", example = "application/json", required = true)
	private String contentType;

	@ApiParam(readOnly = true, name = "enableCQRS", example = "true", required = true)
	private boolean enableCQRS;
}
