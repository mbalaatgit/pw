package com.paywallet.borrower.employer.router;

import static com.paywallet.core.states.constants.AppConstants.ERROR;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.RuntimeCamelException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.bean.validator.BeanValidationException;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paywallet.borrower.employer.models.EmployerResponseDTO;
import com.paywallet.borrower.employer.services.EmployerService;
import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.GeneralHttpResponse;
import com.paywallet.core.states.common.PrepareErrorResponse;
import com.paywallet.core.states.models.CheckEmploymentReturnDTO;

@Component
public class EmployerRouter extends RouteBuilder {

	@Autowired
	private EmployerService employerService;

	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.json).clientRequestValidation(true)
				.apiContextPath("/api-docs").apiProperty("api.title", "Verification APIs")
				.apiProperty("api.version", "1.0.0").apiProperty("cors", "true");

		onException(GeneralHttpException.class, BeanValidationException.class, RuntimeCamelException.class)
				.handled(true).bean(PrepareErrorResponse.class);

		rest("/Employers").get("/ValidateEmployer")
		.securityDefinitions()
			.apiKey("JWT")
			.withHeader("Authorization")
			.end()
		.end()
		.outType(EmployerResponseDTO.class)
		.param()
		.name("employerName")
		.description("Example: Amazon Warehouse,Kroger")
		.type(RestParamType.query)
		.endParam()
		.security("JWT")
		.to("direct:validateEmployer")
		.clientRequestValidation(false);

		from("direct:validateEmployer").bean(employerService, "validateEmployerProcessor").endRest();

		rest("/Employers").get("/CheckEmployment")
		.securityDefinitions()
			.apiKey("JWT")
			.withHeader("Authorization")
			.end()
		.end()
		.param()
			.name("PayrollId")
			.description("Id generated from PayrollProvider/Connect API")
			.type(RestParamType.query)
		.endParam()
		.param()
			.name("PeriodToCover")
			.type(RestParamType.query)
		.endParam()
		.security("JWT")
		.outType(CheckEmploymentReturnDTO.class)
		.to("direct:check-employment")
		.clientRequestValidation(false);
		
		from("direct:check-employment")
		.choice()
        .when(simple("${header.PayrollId} == null")).throwException(new GeneralHttpException(ERROR, "Payroll ID cannot be empty"))
        .when(simple("${header.PeriodToCover} == null")).throwException(new GeneralHttpException(ERROR, "Period to Cover cannot be empty"))
        .otherwise()
		.bean(employerService, "checkEmploymentProcessor").process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				Object body = exchange.getMessage().getBody();
				if (body instanceof GeneralHttpResponse) {
					GeneralHttpResponse<Object> response = (GeneralHttpResponse<Object>) body;
					if (response.getPayload() != null) {
						exchange.getMessage().setBody(response.getPayload());
					} else if (response.isError()) {
						throw new GeneralHttpException(ERROR, response.getMessage());
					}
				}
			}
		}).endRest();
	}

}
