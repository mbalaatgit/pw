package com.paywallet.borrower.customer.models;

import lombok.Data;

@Data
public class AccountOwnerInfoDTO {

	private String accountIsvalid;
	private String ownerShip;
	private String statusOfAccount;
}
