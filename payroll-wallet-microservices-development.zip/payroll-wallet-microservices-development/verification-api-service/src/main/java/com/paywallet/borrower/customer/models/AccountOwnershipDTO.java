package com.paywallet.borrower.customer.models;

import java.util.List;

import lombok.Data;

@Data
public class AccountOwnershipDTO {

	private List<CustomerAcctandOwnershipStatusDTO> customerAcctandOwnershipStatus;
	private String enquiryStatus;
}
