package com.paywallet.borrower.components;

import org.springframework.stereotype.Component;

@Component
public class MyClass {
    public void yoo(){
        System.out.print("Hello");
    }
}
