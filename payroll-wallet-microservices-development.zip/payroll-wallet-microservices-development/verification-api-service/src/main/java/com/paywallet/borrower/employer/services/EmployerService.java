package com.paywallet.borrower.employer.services;

import static com.paywallet.core.states.constants.AppConstants.ERROR;

import org.apache.camel.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.paywallet.borrower.employer.models.EmployerResponseDTO;
import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.GeneralHttpResponse;

@Service
public class EmployerService {

	@Autowired
	private RestTemplate restTemplate;

	@Value("${id-service.host}")
	private String idServiceHost;

	@Value("${id-service.port}")
	private String idServicePort;

	@Value("${payroll-provider-service.host}")
	private String payrollProviderServiceHost;

	@Value("${payroll-provider-service.port}")
	private String payrollProviderServicePort;

	public EmployerResponseDTO validateEmployerProcessor(@Header("employerName") String employerName) {
		String url = "http://" + idServiceHost + ":" + idServicePort + "/api/v1/Employer/Validate";
		if (employerName == null)
			throw new GeneralHttpException(ERROR, "Employer name cannot be empty");

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
		builder.queryParam("employerName", employerName);
		return restTemplate.getForObject(builder.buildAndExpand().toUri(), EmployerResponseDTO.class);
	}

	public GeneralHttpResponse<Object> checkEmploymentProcessor(@Header("PayrollId") String payrollId,
			@Header("PeriodToCover") String periodToCover) {
		String url = "http://" + payrollProviderServiceHost + ":" + payrollProviderServicePort
				+ "/api/v1/employers/check-employment";
		if (payrollId == null) {
			throw new GeneralHttpException(ERROR, "Payroll Id cannot be empty");
		}
		if (periodToCover == null) {
			throw new GeneralHttpException(ERROR, "Period To Cover cannot be empty");
		}
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
		builder.queryParam("PayrollId", payrollId);
		builder.queryParam("PeriodToCover", periodToCover);
		return restTemplate.getForObject(builder.buildAndExpand().toUri(), GeneralHttpResponse.class);
	}

}
