package com.paywallet.borrower.customer.router;

import org.apache.camel.RuntimeCamelException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.bean.validator.BeanValidationException;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestOperationParamDefinition;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paywallet.borrower.customer.models.AccountOwnershipDTO;
import com.paywallet.borrower.customer.services.AccountOwnerShipService;
import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.PrepareErrorResponse;

@Component
public class CustomerRouter extends RouteBuilder {
	
	@Autowired
	private AccountOwnerShipService accountOwnerShipService;
	
	@Override
	public void configure() throws Exception {
		
		restConfiguration().component("servlet").bindingMode(RestBindingMode.json).clientRequestValidation(true);

		onException(GeneralHttpException.class, BeanValidationException.class, RuntimeCamelException.class)
		.handled(true).bean(PrepareErrorResponse.class);
		
		rest("/Customers").get("/CheckAcctStatus")
		.outType(AccountOwnershipDTO.class)
		.securityDefinitions()
			.apiKey("JWT").withHeader("Authorization").end()
		.end()
		.param(setParam("firstName", true, "Example: ED"))
		.param(setParam("middleInitial", false))
		.param(setParam("lastName", true,"Example: JR"))
		.param(setParam("ABANumber", true, "122199983"))
		.param(setParam("acctNumber", true, "10500008945"))
		.security("JWT")
		.bindingMode(RestBindingMode.auto)
		.clientRequestValidation(false)
		.to("direct:CheckAcctStat");

		from("direct:CheckAcctStat").bean(accountOwnerShipService, "validate")
				.bean(accountOwnerShipService, "checkAccountOwnership").endRest();
	}

	private RestOperationParamDefinition setParam(String paramName, boolean required) {
		return new RestOperationParamDefinition().name(paramName).type(RestParamType.query).required(required);
	}

	private RestOperationParamDefinition setParam(String paramName, boolean required, String description) {
		return new RestOperationParamDefinition().name(paramName).type(RestParamType.query).description(description)
				.required(required);
	}

}
