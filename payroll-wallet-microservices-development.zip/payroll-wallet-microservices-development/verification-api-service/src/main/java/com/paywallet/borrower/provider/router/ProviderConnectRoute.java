package com.paywallet.borrower.provider.router;

import static com.paywallet.core.states.constants.AppConstants.ERROR;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.RuntimeCamelException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.bean.validator.BeanValidationException;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.paywallet.borrower.provider.services.ProviderService;
import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.GeneralHttpResponse;
import com.paywallet.core.states.common.PrepareErrorResponse;
import com.paywallet.core.states.models.ProviderConnectRequestDTO;

@Component
public class ProviderConnectRoute extends RouteBuilder {

	@Autowired
	private ProviderService providerService;

	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").enableCORS(false).bindingMode(RestBindingMode.json)
				.clientRequestValidation(true);

		onException(GeneralHttpException.class, BeanValidationException.class, RuntimeCamelException.class,
				HttpClientErrorException.class, HttpServerErrorException.class).handled(true).bean(PrepareErrorResponse.class);

		rest("/PayrollProvider").post("/Connect")
		.securityDefinitions()
			.apiKey("JWT")
			.withHeader("Authorization")
			.end()
		.end()
		.type(ProviderConnectRequestDTO.class)
		.outType(GeneralHttpResponse.class)
		.security("JWT")
		.to("direct:argyle-connect")
		.clientRequestValidation(false);

		from("direct:argyle-connect").process(exchange -> {
			String requestBody = exchange.getIn().getBody(String.class);
			if (requestBody == null || requestBody.equals("")) {
				throw new GeneralHttpException(ERROR, "Bad Request");
			}
		}).to("bean-validator://argyle-connect").bean(providerService, "providerConnectProcessor").choice().when(simple("${body.status} == 0 && ${body.message} != null && ${body.error} == true")).process(new Processor() {
			
			@Override
			public void process(Exchange exchange) throws Exception {
				GeneralHttpResponse body = (GeneralHttpResponse) exchange.getMessage().getBody();
				throw new GeneralHttpException(ERROR, body.getMessage());
			}
		}).endChoice().endRest();
	}
}
