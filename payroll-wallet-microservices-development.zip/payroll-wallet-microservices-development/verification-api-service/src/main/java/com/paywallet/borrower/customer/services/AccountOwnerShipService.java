package com.paywallet.borrower.customer.services;


import org.apache.camel.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.paywallet.borrower.customer.models.AccountOwnershipDTO;
import com.paywallet.borrower.customer.models.AccountOwnershipRequestDTO;
import com.paywallet.core.states.common.GeneralHttpException;

@Service
public class AccountOwnerShipService {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${id-service.host}")
	private String idServiceHost;

	@Value("${id-service.port}")
	private String idServicePort;
	
	private static final String ERROR = "Error";

	public AccountOwnershipRequestDTO validate(@Header(value = "firstName") String firstName,
			@Header(value = "lastName") String lastName, @Header(value = "ABANumber") String abaNumber,
			@Header(value = "acctNumber") String acctNumber, @Header(value = "middleInitial") String middleInitial) {
		
		if (firstName == null || firstName.equals("")) {
			throw new GeneralHttpException(ERROR, "First name cannot be empty !");
		} else if (lastName == null || lastName.equals("")) {
			throw new GeneralHttpException(ERROR, "Last name cannot be empty !");
		} else if (abaNumber == null || abaNumber.equals("")) {
			throw new GeneralHttpException(ERROR, "ABA number cannot be empty !");
		} else if (acctNumber == null || acctNumber.equals("")) {
			throw new GeneralHttpException(ERROR, "Account number cannot be empty !");
		} else {
			return AccountOwnershipRequestDTO.builder().firstName(firstName).middleInitial(middleInitial).lastName(lastName)
					.ABANumber(abaNumber).acctNumber(acctNumber).build();
		}
	}

	public AccountOwnershipDTO checkAccountOwnership(AccountOwnershipRequestDTO requestData) {
		String url = "http://" + idServiceHost + ":" + idServicePort + "/api/v1/Customers/CheckAcctStatus";
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
		builder.queryParam("firstName", requestData.getFirstName());
		builder.queryParam("lastName", requestData.getLastName());
		builder.queryParam("ABANumber", requestData.getABANumber());
		builder.queryParam("acctNumber", requestData.getAcctNumber());
		builder.queryParam("middleInitial", requestData.getMiddleInitial());
		return restTemplate.getForObject(builder.buildAndExpand().toUri(), AccountOwnershipDTO.class);
	}
}
