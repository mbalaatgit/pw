package com.paywallet.borrower.provider.services;

import static com.paywallet.core.states.constants.AppConstants.ERROR;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.GeneralHttpResponse;
import com.paywallet.core.states.models.ProviderConnectRequestDTO;

@Service
public class ProviderService {

	@Autowired
	private RestTemplate restTemplate;

	@Value("${payroll-provider-service.host}")
	private String payrollProviderServiceHost;

	@Value("${payroll-provider-service.port}")
	private String payrollProviderServicePort;

	@Autowired
	private ObjectMapper mapper;

	public GeneralHttpResponse<Object> providerConnectProcessor(ProviderConnectRequestDTO dto) {
		String url = "http://" + payrollProviderServiceHost + ":" + payrollProviderServicePort
				+ "/api/v1/aggregator/connect";
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> request = null;
		try {
			request = new HttpEntity<>(mapper.writeValueAsString(dto), headers);
		} catch (JsonProcessingException e) {
			throw new GeneralHttpException(ERROR, "Request parsing failed !");
		}
		return restTemplate.postForObject(builder.buildAndExpand().toUri(), request, GeneralHttpResponse.class);
	}
}
