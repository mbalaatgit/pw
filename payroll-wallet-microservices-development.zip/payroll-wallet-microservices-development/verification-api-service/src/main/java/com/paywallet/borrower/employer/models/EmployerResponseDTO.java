package com.paywallet.borrower.employer.models;

import java.util.List;

import lombok.Data;

@Data
public class EmployerResponseDTO {

	private String enquiryStatus;
	private List<EmployerDetailsDTO> employers;
}
