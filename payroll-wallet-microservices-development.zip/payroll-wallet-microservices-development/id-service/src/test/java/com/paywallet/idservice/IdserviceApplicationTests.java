package com.paywallet.idservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
