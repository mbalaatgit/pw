package com.paywallet.idservice.customer.component;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestOperationParamDefinition;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paywallet.idservice.customer.models.AccountOwnershipDTO;
import com.paywallet.idservice.customer.services.AccountOwnerShipService;

@Component
public class CustomerComponent extends RouteBuilder {

	@Autowired
	private AccountOwnerShipService accountOwnerShipService;
	
	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.json).clientRequestValidation(true);
		
		rest("/Customers").get("/CheckAcctStatus").outType(AccountOwnershipDTO.class)
		.param(setParam("processType", true, "GetAcctOwnershipandStatus"))
		.param(setParam("Content-Type", true, "application/json")).param(setParam("firstName", true))
		.param(setParam("middleInitial", false)).param(setParam("lastName", true)).param(setParam("ABANumber", true))
		.param(setParam("acctNumber", true)).bindingMode(RestBindingMode.auto).clientRequestValidation(false)
		.to("direct:CheckAcctStat");
		
		from("direct:CheckAcctStat").log("${body}")
		.bean(accountOwnerShipService, "setAccountOwnerShipRequestBody").endRest();
	}

	private RestOperationParamDefinition setParam(String paramName, boolean required) {
		return new RestOperationParamDefinition().name(paramName).type(RestParamType.query).required(required);
	}

	private RestOperationParamDefinition setParam(String paramName, boolean required, String example) {
		return new RestOperationParamDefinition().name(paramName).type(RestParamType.query).example(example)
				.required(required);
	}
}
