package com.paywallet.idservice.customer.enums;

public enum JobStatusEnum {
	PROCESSING, ERROR, COMPLETED
}
