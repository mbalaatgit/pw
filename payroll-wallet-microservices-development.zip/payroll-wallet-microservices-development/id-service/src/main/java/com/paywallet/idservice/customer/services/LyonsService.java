package com.paywallet.idservice.customer.services;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paywallet.idservice.customer.models.LyonsAPIRequestDTO;

@Service
public class LyonsService {

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${lyons.api.baseURL}")
	private String lyonsBaseURL;

	@Value("${lyons.api.companyId}")
	private int companyId;

	@Value("${lyons.api.userName}")
	private String userName;

	@Value("${lyons.api.password}")
	private String password;

	@Value("${lyons.api.returnDetails}")
	private int returnDetails;

	private static final String ERROR = "Error";
	private static final String ERROR_MESSAGE = "errorMessage";
	private static final String RESULT = "result";
	private static final String TOKEN = "token";
	
	public JSONObject checkAccountOwnership(LyonsAPIRequestDTO apiRequest) {
		JSONObject verificationRequest = createAccountVerificationRequest(apiRequest);
		if (verificationRequest.has(ERROR)) {
			return verificationRequest;
		} else {
			return lyonsPostApi("rest/CheckAccountOwnershipAndStatus", verificationRequest.getString("requestString"));
		}
	}

	private JSONObject createAccountVerificationRequest(LyonsAPIRequestDTO apiRequest) {
		JSONObject requestDataObject = new JSONObject();

		JSONObject tokenObj = getLyonsToken();

		JSONObject result = tokenObj.has(RESULT) ? tokenObj.getJSONObject(RESULT) : null;

		if (result == null) {
			Object errorMessage = tokenObj.get(ERROR);
			requestDataObject.put(ERROR, errorMessage);
		} else if (!result.has(TOKEN) || result.get(TOKEN) == null) {
			Object errorMessage = result.has(ERROR_MESSAGE) ? result.get(ERROR_MESSAGE) : null;
			if (errorMessage != null) {
				requestDataObject.put(ERROR, errorMessage);
			} else {
				requestDataObject.put(ERROR, "Failed to log on");
			}
		} else {
			apiRequest.setToken(result.get(TOKEN).toString());
			apiRequest.setReturnDetails(returnDetails);
			apiRequest.initRequest();
			try {
				requestDataObject.put("requestString", objectMapper.writeValueAsString(apiRequest));
			} catch (JsonProcessingException e) {
				requestDataObject.put(ERROR, "Lyons request parsing failed !");
			}
		}
		return requestDataObject;
	}

	private JSONObject getLyonsToken() {
		JSONObject request = new JSONObject();
		request.put("companyId", companyId);
		request.put("userName", userName);
		request.put("password", password);
		return lyonsPostApi("rest/Logon", request.toString());
	}

	private JSONObject lyonsPostApi(String endpoint, String jsonRequestBody) {
		JSONObject apiResponseData = new JSONObject();
		HttpEntity<String> request = new HttpEntity<>(jsonRequestBody, getRequestHeader());
		try {
			String result = restTemplate.postForObject(this.lyonsBaseURL + endpoint, request, String.class);
			apiResponseData.put(RESULT, new JSONObject(result));
		} catch (JSONException err) {
			apiResponseData.put(ERROR, "Lyons response parsing failed !");
		} catch (HttpClientErrorException ex) {
			apiResponseData.put(ERROR, "Error while communicating with Lyons API !");
		}
		return apiResponseData;
	}

	private HttpHeaders getRequestHeader() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return headers;
	}

}
