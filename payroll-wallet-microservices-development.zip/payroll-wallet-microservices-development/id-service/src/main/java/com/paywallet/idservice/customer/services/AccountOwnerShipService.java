package com.paywallet.idservice.customer.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Header;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paywallet.idservice.customer.enums.JobStatusEnum;
import com.paywallet.idservice.customer.enums.VerificationStatusEnum;
import com.paywallet.idservice.customer.models.AccountOwnerInfoDTO;
import com.paywallet.idservice.customer.models.AccountOwnershipDTO;
import com.paywallet.idservice.customer.models.AccountOwnershipRequestDTO;
import com.paywallet.idservice.customer.models.CustomerAcctandOwnershipStatusDTO;
import com.paywallet.idservice.customer.models.LyonsAPIRequestDTO;

@Service
public class AccountOwnerShipService {

	@Autowired
	private LyonsService lyonsService;

	private static final String VALID_RTN = "validRtn";
	private static final String STATUS_DESC = "statusDescription";
	private static final String RESULT = "result";
	private static final String STATUS_CODE = "statusCode";

	public AccountOwnershipDTO setAccountOwnerShipRequestBody(@Header(value = "firstName") String firstName,
			@Header(value = "lastName") String lastName, @Header(value = "ABANumber") String abaNumber,
			@Header(value = "acctNumber") String acctNumber, @Header(value = "middleInitial") String middleInitial) {
		return checkAccountOwnership(AccountOwnershipRequestDTO.builder().firstName(firstName)
				.middleInitial(middleInitial).lastName(lastName).ABANumber(abaNumber).acctNumber(acctNumber).build());
	}

	private AccountOwnershipDTO checkAccountOwnership(AccountOwnershipRequestDTO requestData) {
		AccountOwnershipDTO accountOwnerShipDTO = new AccountOwnershipDTO();
		try {
			LyonsAPIRequestDTO lyonsApiRequest = LyonsAPIRequestDTO.builder().firstName(requestData.getFirstName())
					.middleName(requestData.getMiddleInitial()).lastName(requestData.getLastName())
					.accountNumber(requestData.getAcctNumber()).abaNumber(requestData.getABANumber()).build();
			JSONObject accountOwnership = lyonsService.checkAccountOwnership(lyonsApiRequest);
			if (accountOwnership.has(RESULT)) {
				List<CustomerAcctandOwnershipStatusDTO> acctOwnerShipStatus = setAcctOwnerShipStatus(requestData,
						accountOwnership.getJSONObject(RESULT));
				AccountOwnerInfoDTO accountOwnerInfo = acctOwnerShipStatus.get(0).getAccountOwnerInfo();
				if (accountOwnerInfo.getOwnerShip() != null
						&& (accountOwnerInfo.getOwnerShip().equals(VerificationStatusEnum.ACCEPT.toString())
								|| accountOwnerInfo.getOwnerShip().equals(VerificationStatusEnum.DENY.toString())
								|| accountOwnerInfo.getOwnerShip().equals(VerificationStatusEnum.REVIEW.toString()))) {
					accountOwnerShipDTO.setEnquiryStatus(JobStatusEnum.COMPLETED.toString());
					accountOwnerShipDTO.setCustomerAcctandOwnershipStatus(acctOwnerShipStatus);
				} else {
					accountOwnerShipDTO.setEnquiryStatus(JobStatusEnum.ERROR.toString());
				}
			} else {
				accountOwnerShipDTO.setEnquiryStatus(JobStatusEnum.ERROR.toString());
			}
		} catch (Exception e) {
			accountOwnerShipDTO.setEnquiryStatus(JobStatusEnum.ERROR.toString());
		}
		return accountOwnerShipDTO;
	}

	private List<CustomerAcctandOwnershipStatusDTO> setAcctOwnerShipStatus(AccountOwnershipRequestDTO requestData,
			JSONObject accountOwnership) {
		List<CustomerAcctandOwnershipStatusDTO> accountAndOwnerShipStatus = new ArrayList<>();
		CustomerAcctandOwnershipStatusDTO acctAndOwnerShipStatus = new CustomerAcctandOwnershipStatusDTO();
		acctAndOwnerShipStatus.setAbaNumber(requestData.getABANumber());
		acctAndOwnerShipStatus.setAccountNumber(requestData.getAcctNumber());
		acctAndOwnerShipStatus.setAccountOwnerInfo(setAccountOwnerInfo(accountOwnership));
		acctAndOwnerShipStatus.setFirstName(requestData.getFirstName());
		acctAndOwnerShipStatus.setLastName(requestData.getLastName());
		if (requestData.getMiddleInitial() != null)
			acctAndOwnerShipStatus.setMiddleName(requestData.getMiddleInitial());
		accountAndOwnerShipStatus.add(acctAndOwnerShipStatus);
		return accountAndOwnerShipStatus;
	}

	private AccountOwnerInfoDTO setAccountOwnerInfo(JSONObject result) {
		AccountOwnerInfoDTO accountOwnerInfo = new AccountOwnerInfoDTO();
		long statusCode = result.has(STATUS_CODE) ? result.getLong(STATUS_CODE) : 0l;
		String statusDescription = result.has(STATUS_DESC) ? result.getString(STATUS_DESC) : null;
		boolean validRtn = result.has(VALID_RTN) ? result.getBoolean(VALID_RTN) : Boolean.FALSE;
		if (statusCode == VerificationStatusEnum.Values.ACCEPT_CODE
				&& VerificationStatusEnum.Values.ACCEPT.equals(statusDescription) && validRtn) {
			accountOwnerInfo.setAccountIsvalid("true");
			accountOwnerInfo.setOwnerShip(VerificationStatusEnum.ACCEPT.toString());
			accountOwnerInfo.setStatusOfAccount(accountOwnerInfo.getOwnerShip());
		} else if (statusCode == 103 || statusCode == 104) {
			accountOwnerInfo.setAccountIsvalid("false");
			accountOwnerInfo.setOwnerShip(VerificationStatusEnum.DENY.toString());
			accountOwnerInfo.setStatusOfAccount(accountOwnerInfo.getOwnerShip());
		} else {
			accountOwnerInfo.setAccountIsvalid("UNABLE_TO_VALIDATE");
			accountOwnerInfo.setOwnerShip(VerificationStatusEnum.REVIEW.toString());
			accountOwnerInfo.setStatusOfAccount(accountOwnerInfo.getOwnerShip());
		}

		return accountOwnerInfo;
	}
}
