package com.paywallet.idservice.customer.models;

import java.util.List;

import lombok.Data;

@Data
public class AccountOwnershipDTO {

	private List<CustomerAcctandOwnershipStatusDTO> customerAcctandOwnershipStatus;
	private String enquiryStatus;
}
