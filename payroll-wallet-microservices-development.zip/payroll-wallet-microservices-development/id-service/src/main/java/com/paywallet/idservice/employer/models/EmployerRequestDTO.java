package com.paywallet.idservice.employer.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EmployerRequestDTO {

	private String processType;
	private String employerName;
	@Builder.Default
	private Integer limit = 5;
}
