package com.paywallet.idservice.employer.models;

import java.util.List;

import lombok.Data;

@Data
public class EmployerDetailsDTO {

	private String id;
	private String employerName;
	private boolean validEmployer = false;
	private boolean active;
	private List<String> probableEmployers;
}
