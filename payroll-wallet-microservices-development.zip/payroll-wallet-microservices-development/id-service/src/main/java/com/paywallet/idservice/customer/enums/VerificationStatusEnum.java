package com.paywallet.idservice.customer.enums;

public enum VerificationStatusEnum {
	ACCEPT, DENY, REVIEW;

	public static class Values {
		private Values() {
		}

		public static final String ACCEPT = "Accept";
		public static final String DENY = "Deny";
		public static final long ACCEPT_CODE = 101;
	}
}
