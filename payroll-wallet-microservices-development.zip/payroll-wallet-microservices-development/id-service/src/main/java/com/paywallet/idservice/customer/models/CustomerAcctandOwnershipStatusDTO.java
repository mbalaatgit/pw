package com.paywallet.idservice.customer.models;

import lombok.Data;

@Data
public class CustomerAcctandOwnershipStatusDTO {

	private String abaNumber;
	private String accountNumber;
	private AccountOwnerInfoDTO accountOwnerInfo;
	private String firstName;
	private String lastName;
	private String middleName;
	private String label;
	private String type = "String";
}
