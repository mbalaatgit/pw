package com.paywallet.idservice.employer.services;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.camel.Header;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.paywallet.idservice.employer.models.EmployerDetailsDTO;
import com.paywallet.idservice.employer.models.EmployerRequestDTO;
import com.paywallet.idservice.employer.models.EmployerResponseDTO;

@Service
public class EmployerService {
	
	@Value("${argyle.link.base}")
	private String argyleLinkBasePath;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public EmployerResponseDTO validateEmployerProcessor(@Header("employerName") String employerName) {
//		if (employerName == null)
//			throw new GeneralHttpException("Error", "Employer name cannot be empty");
		EmployerRequestDTO employerDTO = EmployerRequestDTO.builder().employerName(employerName).build();
		return validateEmployer(employerDTO);
	}
	
	private EmployerResponseDTO validateEmployer(EmployerRequestDTO request) {
		EmployerResponseDTO employerResponseDTO = new EmployerResponseDTO(); 
		HttpEntity<String> requestEntity = new HttpEntity<>(this.getBasicAuthHeader());
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(argyleLinkBasePath + "link-items")
         .queryParam("search", request.getEmployerName()).queryParam("category", "company")
         .queryParam("pd_support", "true").queryParam("limit", request.getLimit());
		 String result = restTemplate.exchange(uriBuilder.toUriString(), HttpMethod.GET, requestEntity, String.class)
         .getBody();
		 if (result != null) {
			 employerResponseDTO.setEmployers(setEmployerResposneDTO(new JSONObject(result), request.getEmployerName()));
			 if (!CollectionUtils.isEmpty(employerResponseDTO.getEmployers())) {
				 if (employerResponseDTO.getEmployers().get(0).getId() != null) {
					 employerResponseDTO.setEnquiryStatus("ENQUIRY_SUCCESS");
				 } else {
					 employerResponseDTO.setEnquiryStatus("ENQUIRY_SUGGESTIONS");
				 }
			 } else {
				 employerResponseDTO.setEnquiryStatus("NO_MATCH");
			 }
		 } else {
			 employerResponseDTO.setEnquiryStatus("NO_MATCH");
		 }
		return employerResponseDTO;
	}

	private List<EmployerDetailsDTO> setEmployerResposneDTO(JSONObject response, String employerName) {
		JSONArray results = response.getJSONArray("results");
		List<EmployerDetailsDTO> employerDetails = new ArrayList<>();
		if (results.length() > 0) {
			EmployerDetailsDTO employerDetailsDTO = new EmployerDetailsDTO();
			List<String> probableEmployers = new ArrayList<>();
			String id = null;
			String matchedEmployerName = null;
			for (int i = 0; i < results.length(); i++) {
				if (results.getJSONObject(i).getString("name").equalsIgnoreCase(employerName)){
					id = results.getJSONObject(i).getString("id");
					matchedEmployerName = results.getJSONObject(i).getString("name");
				}
				probableEmployers.add(results.getJSONObject(i).getString("name"));
			}
			if (id != null) {
				employerDetailsDTO.setValidEmployer(true);
				employerDetailsDTO.setActive(true);
				employerDetailsDTO.setEmployerName(matchedEmployerName);
			}
			else{
				employerDetailsDTO.setActive(false);
				employerDetailsDTO.setEmployerName(employerName);
			}

			employerDetailsDTO.setId(id);
			employerDetailsDTO.setProbableEmployers(probableEmployers);
			employerDetails.add(employerDetailsDTO);
		}
		return employerDetails;
	}

	private HttpHeaders getBasicAuthHeader() {
		HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
	}
}
