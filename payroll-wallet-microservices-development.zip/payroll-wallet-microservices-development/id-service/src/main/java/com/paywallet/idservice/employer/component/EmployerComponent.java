package com.paywallet.idservice.employer.component;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mongodb.MongoDbConstants;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mongodb.client.model.Filters;
import com.paywallet.idservice.employer.models.EmployerResponseDTO;
import com.paywallet.idservice.employer.services.EmployerService;

@Component
public class EmployerComponent extends RouteBuilder {

	@Autowired
	private EmployerService employerService;

	@Value("${argyle.employers.connection.uri}")
	private String argyleEmployersConnUrl;

	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.json).clientRequestValidation(true);

		rest("/Employer").get("/Validate").param().name("employerName").type(RestParamType.query).endParam()
				.to("direct:validateEmployer").clientRequestValidation(false);

		from("direct:validateEmployer").log("${header.employerName}").bean(employerService, "validateEmployerProcessor")
				.setProperty("requestBody", body()).choice()
				.when(simple(
						"${body.employers} != null && ${body.employers.size()} > 0 && ${body.employers.get(0).getId()} != null"))
				.setHeader(MongoDbConstants.CRITERIA, new Expression() {
					@Override
					public <T> T evaluate(Exchange exchange, Class<T> type) {
						EmployerResponseDTO requestDTO = (EmployerResponseDTO) exchange.getIn().getBody();
						Bson equalToEmployerId = Filters.eq("providerId", requestDTO.getEmployers().get(0).getId());
						return exchange.getContext().getTypeConverter().convertTo(type, equalToEmployerId);
					}
				}).to(argyleEmployersConnUrl + "&operation=findOneByQuery").transform(new Expression() {
					public <T> T evaluate(Exchange exchange, Class<T> type) {
						Document doc = (Document) exchange.getIn().getBody();
						EmployerResponseDTO response = (EmployerResponseDTO) exchange.getProperty("requestBody");
						if (doc != null) {
							String employerId = doc.getString("employerId");
							if (employerId != null) {
								response.getEmployers().get(0).setId(employerId);
							}
						}
						exchange.getIn().setBody(response);
						return (T) response;
					}
				}).endChoice().endRest();
	}

}
