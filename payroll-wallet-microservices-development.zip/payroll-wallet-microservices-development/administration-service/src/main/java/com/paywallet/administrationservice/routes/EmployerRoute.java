package com.paywallet.administrationservice.routes;
import org.apache.camel.RuntimeCamelException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import com.paywallet.administrationservice.components.SyncArgyleComponent;
import com.paywallet.administrationservice.general.PrepareErrorResponse;

@Component
public class EmployerRoute extends RouteBuilder {
	
    @Value("${argyle.base}")
    private String argyleBasePath;
    
    @Autowired
    SyncArgyleComponent syncComponent;

	  @Override
	    public void configure() throws Exception {

	        restConfiguration().component("servlet").enableCORS(false).bindingMode(RestBindingMode.json)
	                .clientRequestValidation(false);
	        
	        onException(RuntimeCamelException.class, ResourceAccessException.class).handled(true).bean(PrepareErrorResponse.class);
	        
	        rest("/sync")
	        .get("/argyle")
	        .to("direct:setArgyleUrl");
	        
	        from("direct:setArgyleUrl")
	        .setProperty("url", simple(argyleBasePath + "link-items?limit=200&offset=0"))
	        .setProperty("batch", simple("0"))
	        .to("direct:syncArgyle");
	        
	        from("direct:syncArgyle")
	        .bean(syncComponent, "syncArgyle")
	        .choice()
	        .when().simple("${body} != 'null' && ${body} != null && ${body} != ''")
	        .to("direct:syncArgyle")
	        .otherwise()
	        .process(exchange -> {
	        	exchange.getIn().setBody("Successfully Synced");
	        })
	        .endRest(); 
	  }
}