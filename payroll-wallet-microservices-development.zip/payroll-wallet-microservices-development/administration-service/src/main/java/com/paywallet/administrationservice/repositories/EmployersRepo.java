package com.paywallet.administrationservice.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.paywallet.administrationservice.entities.Employers;

@Repository
public interface EmployersRepo extends MongoRepository<Employers, String> {
	public Employers findByName(String name);
}