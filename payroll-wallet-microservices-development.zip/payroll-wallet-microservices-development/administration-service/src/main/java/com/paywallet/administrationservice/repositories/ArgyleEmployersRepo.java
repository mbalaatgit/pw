package com.paywallet.administrationservice.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.paywallet.administrationservice.entities.ArgyleEmployers;

@Repository
public interface ArgyleEmployersRepo extends MongoRepository<ArgyleEmployers, String> {
}