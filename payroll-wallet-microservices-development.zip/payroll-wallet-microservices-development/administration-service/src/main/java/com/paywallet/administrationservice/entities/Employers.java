package com.paywallet.administrationservice.entities;

import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paywallet.administrationservice.enumerations.ProviderTypeEnum;

import lombok.Data;

@Data
@Document("Employers")
public class Employers {
	@Id
	private String employerId;
	private String name;
	private List<ProviderTypeEnum> supported;
	private List<ProviderTypeEnum> pdSupported;
}
