package com.paywallet.administrationservice.enumerations;

public enum ProviderTypeEnum {
	ARGYLE
}
