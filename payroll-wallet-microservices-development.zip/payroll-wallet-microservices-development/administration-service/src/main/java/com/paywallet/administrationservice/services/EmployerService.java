package com.paywallet.administrationservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paywallet.administrationservice.entities.Employers;
import com.paywallet.administrationservice.repositories.EmployersRepo;

@Service
public class EmployerService {
	@Autowired
	EmployersRepo employersRepo;
	
	public Employers getByName(String name) {
		return employersRepo.findByName(name);
	}
	
	public Employers saveEmployer(Employers employer) {
		return employersRepo.save(employer);
	}
}
