package com.paywallet.administrationservice.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document("ArgyleEmployers")
public class ArgyleEmployers {
	@Id
	private String id;
	@Indexed(unique=true, sparse=true)
	private String employerId;
	@Indexed(unique=true, sparse=true)
	private String providerId;
	private Boolean payDistribution;
}
