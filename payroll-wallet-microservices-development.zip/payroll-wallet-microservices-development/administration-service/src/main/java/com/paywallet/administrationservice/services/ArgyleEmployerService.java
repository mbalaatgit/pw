package com.paywallet.administrationservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paywallet.administrationservice.entities.ArgyleEmployers;
import com.paywallet.administrationservice.repositories.ArgyleEmployersRepo;

@Service
public class ArgyleEmployerService {
	
	@Autowired
	ArgyleEmployersRepo repo;
	
	public ArgyleEmployers saveArgyleEmployer(ArgyleEmployers employer) {
		return repo.save(employer);
	}
}
