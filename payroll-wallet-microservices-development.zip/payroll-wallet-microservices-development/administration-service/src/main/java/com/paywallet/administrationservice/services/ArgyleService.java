package com.paywallet.administrationservice.services;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ArgyleService {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${argyle.token}")
    private String argyleToken;
	
    public JSONObject getLinkItems(String url) {
        HttpEntity<String> requestEntity = new HttpEntity<>(this.getBasicAuthHeader());
        String result = this.restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class)
                .getBody();
        try {
            return new JSONObject(result);
        } catch (JSONException err) {
            return null;
        }
    }
    
    private HttpHeaders getBasicAuthHeader() {
        byte[] plainCredsBytes = argyleToken.getBytes();
        byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
        String base64Creds = new String(base64CredsBytes);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Authorization", "Basic " + base64Creds);
        return headers;
    }
    
}
