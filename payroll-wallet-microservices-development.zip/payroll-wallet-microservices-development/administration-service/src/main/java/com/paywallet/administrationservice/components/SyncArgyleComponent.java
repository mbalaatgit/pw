package com.paywallet.administrationservice.components;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperty;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paywallet.administrationservice.entities.ArgyleEmployers;
import com.paywallet.administrationservice.entities.Employers;
import com.paywallet.administrationservice.enumerations.ProviderTypeEnum;
import com.paywallet.administrationservice.services.ArgyleEmployerService;
import com.paywallet.administrationservice.services.ArgyleService;
import com.paywallet.administrationservice.services.EmployerService;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class SyncArgyleComponent {

	@Autowired
	ArgyleService argyleService;

	@Autowired
	EmployerService employerService;

	@Autowired
	ArgyleEmployerService argyleEmployerService;

	private static final String RESULTS = "results";
	private static final String NEXT = "next";

	public String syncArgyle(@ExchangeProperty(value = "url") String url, Exchange exchange,
			@ExchangeProperty(value = "batch") long batch) {
		JSONObject results = this.argyleService.getLinkItems(url);
		JSONArray employers = results.getJSONArray(RESULTS);
		exchange.setProperty("url", results.optString(NEXT));
		long count = 0;
		if (employers.length() > 0) {
			for (int i = 0; i < employers.length(); i++) {
				JSONObject emp = employers.getJSONObject(i);

				JSONObject features = emp.optJSONObject("features");
				if (features != null && !emp.getBoolean("is_disabled")) {
					boolean payDistSupported = false;
					if (features.optJSONObject("pay_distribution_update").getBoolean("supported")
							&& features.optJSONObject("pay_distribution_update").getBoolean("amount_allocation")) {
						payDistSupported = true;
					}
					count++;
					Employers employer = employerService.getByName(emp.getString("name"));
					if (employer != null) {
						if (employer.getSupported() == null
								|| !employer.getSupported().contains(ProviderTypeEnum.ARGYLE)) {
							List<ProviderTypeEnum> providerEnum = employer.getSupported();
							List<ProviderTypeEnum> pdSupported = employer.getPdSupported();
							if (providerEnum == null) {
								providerEnum = new ArrayList<>();
							}
							providerEnum.add(ProviderTypeEnum.ARGYLE);
							employer.setSupported(providerEnum);
							if (pdSupported == null) {
								pdSupported = new ArrayList<>();
							}
							if (payDistSupported) {
								pdSupported.add(ProviderTypeEnum.ARGYLE);
							}
							employer.setPdSupported(pdSupported);
							Employers savedEmp = employerService.saveEmployer(employer);
							this.addArgyleEmployer(savedEmp.getEmployerId(), emp.getString("id"), payDistSupported);
						}
					} else {
						String employerId = this.addNewEmployee(emp.getString("name"), payDistSupported);
						this.addArgyleEmployer(employerId, emp.getString("id"), payDistSupported);
					}
				}
			}
			log.info("batch " + (batch + 1) + ", " + count + " processed");
			exchange.setProperty("batch", batch + 1);
		}
		return results.optString(NEXT);
	}

	private String addNewEmployee(String name, boolean pdSupported) {
		Employers newEmp = new Employers();
		newEmp.setEmployerId(UUID.randomUUID().toString());
		newEmp.setName(name);
		List<ProviderTypeEnum> providerEnum = new ArrayList<>();
		providerEnum.add(ProviderTypeEnum.ARGYLE);
		newEmp.setSupported(providerEnum);
		List<ProviderTypeEnum> pdSupport = new ArrayList<>();
		if (pdSupported) {
			pdSupport.add(ProviderTypeEnum.ARGYLE);
		}
		newEmp.setPdSupported(pdSupport);
		Employers savedEmp = employerService.saveEmployer(newEmp);
		return savedEmp.getEmployerId();
	}

	private void addArgyleEmployer(String employerId, String providerId, boolean payDistSupported) {
		ArgyleEmployers argyleEmp = new ArgyleEmployers();
		argyleEmp.setEmployerId(employerId);
		argyleEmp.setProviderId(providerId);
		argyleEmp.setPayDistribution(payDistSupported);
		argyleEmp.setId(UUID.randomUUID().toString());
		argyleEmployerService.saveArgyleEmployer(argyleEmp);
	}

}
