package com.paywallet.payrollproviderservice.entities;

import java.util.UUID;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document("ArgyleAccounts")
@CompoundIndex(name = "userId_accountId", def = "{'userId' : 1, 'accountId': 1}", unique = true)
public class ArgyleAccounts {

	@Id
	private UUID id;
	private String userId;
	private String accountId;
	private String payAllocationId;
	private String payrollId;
}