package com.paywallet.payrollproviderservice.components;

import static com.paywallet.core.states.constants.AppConstants.SUCCESS;
import static com.paywallet.core.states.constants.AppConstants.ERROR;

import org.apache.camel.Body;
import org.apache.camel.ExchangeProperty;
import org.bson.Document;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.GeneralHttpResponse;
import com.paywallet.core.states.models.ProviderConnectRequestDTO;
import com.paywallet.payrollproviderservice.entities.ArgyleCredentials;
import com.paywallet.core.states.models.CheckEmploymentReturnDTO;
import com.paywallet.payrollproviderservice.entities.ArgyleEmployers;
import com.paywallet.payrollproviderservice.models.ArgyleCredentialsModel;
import com.paywallet.payrollproviderservice.models.PayrollLoginInputDTO;
import com.paywallet.payrollproviderservice.models.ProviderReauthenticateRequestDTO;

@Component
public class TransformComponent {
	public PayrollLoginInputDTO transformToArgyleAccountCreationModel(@Body JSONObject body,
			@ExchangeProperty(value = "requestBody") ProviderConnectRequestDTO requestDTO,
			@ExchangeProperty(value = "argyleEmployer") ArgyleEmployers argyleEmployer) {
		ArgyleCredentialsModel argyleCredentialsModel = new ArgyleCredentialsModel(requestDTO.getUsername(),
				requestDTO.getPassword());
		String argyleId = body.getString("id");
		String argyleToken = body.getString("token");
		return new PayrollLoginInputDTO(argyleCredentialsModel, argyleEmployer.getProviderId(), argyleId, argyleToken);
	}

	public PayrollLoginInputDTO transformToArgyleAccountUpdationModel(@Body JSONObject body,
			@ExchangeProperty(value = "requestBody") ProviderReauthenticateRequestDTO requestDTO,
			@ExchangeProperty(value = "argyleEmployer") ArgyleEmployers argyleEmployer) {
		ArgyleCredentialsModel argyleCredentialsModel = new ArgyleCredentialsModel(requestDTO.getUsername(),
				requestDTO.getPassword());
		String argyleId = body.getString("id");
		String argyleToken = body.getString("token");
		return new PayrollLoginInputDTO(argyleCredentialsModel, argyleEmployer.getProviderId(), argyleId, argyleToken);
	}

	public GeneralHttpResponse<String> transformToConnectResponse(String payrollId) {
		return new GeneralHttpResponse<>(payrollId, 200, false, "SUCCESS", null);
	}

	public GeneralHttpResponse<CheckEmploymentReturnDTO> checkEmploymentReturnDTOToGeneralHttpResponse(
			@Body CheckEmploymentReturnDTO dto) {
		return new GeneralHttpResponse<CheckEmploymentReturnDTO>().setPayload(dto).setStatus(200).setMessage(SUCCESS);
	}

	public ArgyleEmployers employerFromDBToArgyleEmployerDto(@Body Document doc) {
		ArgyleEmployers argyleEmp = new ArgyleEmployers();
		try {
			argyleEmp.setId(doc.getString("_id"));
			argyleEmp.setEmployerId(doc.getString("employerId"));
			argyleEmp.setProviderId(doc.getString("providerId"));
		} catch (NullPointerException ex) {
			throw new GeneralHttpException(ERROR, "Employer doesnt exist for the given ID");
		}
		return argyleEmp;
	}
}
