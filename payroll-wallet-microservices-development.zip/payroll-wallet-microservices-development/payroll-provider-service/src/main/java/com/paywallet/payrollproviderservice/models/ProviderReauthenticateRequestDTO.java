package com.paywallet.payrollproviderservice.models;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class ProviderReauthenticateRequestDTO {
    @NotNull
    private String username;
    @NotNull
    private String password;
    @NotNull
    private String payrollId;
}