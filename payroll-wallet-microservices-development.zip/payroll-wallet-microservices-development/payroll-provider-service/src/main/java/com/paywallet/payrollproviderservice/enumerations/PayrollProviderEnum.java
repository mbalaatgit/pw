package com.paywallet.payrollproviderservice.enumerations;

public enum PayrollProviderEnum {
	ARGYLE
}
