package com.paywallet.payrollproviderservice.entities;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "ArgyleEmployer")
public class ArgyleEmployer {

	private String employerId;
	private String providerId;

}
