package com.paywallet.payrollproviderservice.entities;

import org.springframework.data.mongodb.core.mapping.Document;

import com.paywallet.payrollproviderservice.enumerations.PayrollProviderEnum;

import lombok.Data;

@Data
@Document(collection = "Employer")
public class Employer {

	private String employerId;
	private String employerName;
	private PayrollProviderEnum supported;
}
