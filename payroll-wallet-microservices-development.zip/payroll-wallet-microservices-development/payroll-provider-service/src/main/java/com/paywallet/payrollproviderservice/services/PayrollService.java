package com.paywallet.payrollproviderservice.services;

import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;

import org.apache.camel.Body;
import org.apache.camel.ExchangeProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paywallet.core.states.models.ProviderConnectRequestDTO;
import com.paywallet.core.states.models.CheckEmploymentDTO;
import com.paywallet.payrollproviderservice.entities.Payroll;
import com.paywallet.payrollproviderservice.enumerations.PayrollProviderEnum;
import com.paywallet.payrollproviderservice.models.ProviderReauthenticateRequestDTO;
import com.paywallet.payrollproviderservice.repositories.PayrollRepository;

@Service
public class PayrollService {
	
	@Autowired
	PayrollRepository payrollRepo;
	
	public Payroll savePayrollData(@ExchangeProperty(value = "requestBody") ProviderConnectRequestDTO requestDTO) {

		Optional<Payroll> payroll = payrollRepo.findByUsernameAndEmployer(requestDTO.getUsername(),
				requestDTO.getEmployerId());
		Payroll payrollDetails = null;
		if (payroll.isPresent()) {
			payrollDetails = payroll.get();
		} else {
			payrollDetails = new Payroll();
			payrollDetails.setPayrollId(UUID.randomUUID().toString());
			payrollDetails.setUsername(requestDTO.getUsername());
			payrollDetails.setEmployer(requestDTO.getEmployerId());
			payrollDetails.setProvider(PayrollProviderEnum.ARGYLE);
			payrollDetails.setConnectedOn(new Date());
		}
		payrollRepo.save(payrollDetails);
		return payrollDetails;
	}

	public Payroll updatePayrollData(@ExchangeProperty(value = "requestBody") ProviderReauthenticateRequestDTO requestDTO) {

		Optional<Payroll> payroll = payrollRepo.findByPayrollId(requestDTO.getPayrollId());
		Payroll payrollData = new Payroll();
		if (payroll.isPresent()) {
			payrollData = payroll.get();
			payrollData.setConnectedOn(new Date());
			payrollRepo.save(payrollData);
		} else {
			throw new NoSuchElementException("No record found for the given Payroll ID");
		}
		return payrollData;
	}
	
	public Payroll checkPayrollData(@ExchangeProperty(value = "requestBody") ProviderConnectRequestDTO requestDTO) {
		Optional<Payroll> payroll = payrollRepo.findByUsernameAndEmployer(requestDTO.getUsername(),
				requestDTO.getEmployerId());
		if (payroll.isPresent()) {
			return payroll.get();
		} else {
			return null;
		}
	}

	public Payroll checkPayrollUsername(@ExchangeProperty(value = "requestBody") ProviderReauthenticateRequestDTO requestDTO) {
		Optional<Payroll> payroll = payrollRepo.findByPayrollId(requestDTO.getPayrollId());
		if (payroll.isPresent()) {
			return payroll.get();
		} else {
			return null;
		}
	}
}
