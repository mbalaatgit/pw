package com.paywallet.payrollproviderservice.models;

import lombok.Data;

@Data
public class ArgyleStatusModel {
    private String status;
    private String errorCode;
}