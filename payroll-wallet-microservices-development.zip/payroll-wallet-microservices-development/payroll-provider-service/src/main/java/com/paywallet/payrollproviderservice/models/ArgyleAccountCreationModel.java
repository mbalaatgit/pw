package com.paywallet.payrollproviderservice.models;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ArgyleAccountCreationModel {
    String employerId;
    String userId;
    String accountId;
    String mfaType;
    String mfaMessage;
    String token;
}

