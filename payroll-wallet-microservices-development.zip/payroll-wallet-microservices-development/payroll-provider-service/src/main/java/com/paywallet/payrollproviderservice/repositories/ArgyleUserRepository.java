package com.paywallet.payrollproviderservice.repositories;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.paywallet.payrollproviderservice.entities.ArgyleUser;


@Repository
public interface ArgyleUserRepository extends MongoRepository<ArgyleUser, String> {
	
	Optional<ArgyleUser> findByUsernameAndEmployerId(String username, String employerId);
	Optional<ArgyleUser> findById(String id);
}