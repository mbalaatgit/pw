package com.paywallet.payrollproviderservice.routes;



import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.RuntimeCamelException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.bean.validator.BeanValidationException;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.GeneralHttpResponse;
import com.paywallet.core.states.models.CheckEmploymentDTO;
import com.paywallet.payrollproviderservice.components.CheckEmploymentComponent;
import com.paywallet.payrollproviderservice.components.TransformComponent;
import com.paywallet.payrollproviderservice.services.ArgyleService;
import com.paywallet.payrollproviderservice.services.PayrollService;

@Component
public class EmployerRoute extends RouteBuilder {

    @Autowired
    CheckEmploymentComponent checkEmployment;
    
    @Autowired
    ArgyleService argyleService;
    
    @Autowired
    PayrollService payrollService; 
    

    @Override
    public void configure() throws Exception {

        restConfiguration().component("servlet").enableCORS(false).bindingMode(RestBindingMode.json)
                .clientRequestValidation(false);

		onException(GeneralHttpException.class, BeanValidationException.class, RuntimeCamelException.class,
				HttpClientErrorException.class, HttpServerErrorException.class).handled(true).process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						Throwable cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
				        Message msg = exchange.getMessage();
				        msg.setHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON);
				        msg.setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
				        GeneralHttpResponse<Object> response = new GeneralHttpResponse<>();
				        response.setMessage(cause.getMessage());
				        response.setError(true);
				        msg.setBody(response);
					}
				});

        rest("/employers")
        .get("/check-employment")
        .param().name("PayrollId").type(RestParamType.query).endParam()
        .param().name("PeriodToCover").type(RestParamType.query).endParam()
        .outType(GeneralHttpResponse.class)
        .to("direct:checkEmployment");

        from("direct:checkEmployment")
                .process(exchange -> {
                    Message message = exchange.getIn();
                    CheckEmploymentDTO checkEmploymentDTO = new CheckEmploymentDTO();
                    checkEmploymentDTO.setPayrollId(message.getHeader("PayrollId").toString());
                    checkEmploymentDTO.setPeriodToCover(message.getHeader("PeriodToCover").toString());
                    exchange.getIn().setBody(checkEmploymentDTO);
                })
                .setProperty("checkEmploymentDTO", body())
                .bean(argyleService, "getArgyleUserData")
                .setProperty("argyleUserDetailsFromDB", body())
                .bean(checkEmployment, "getPayAllocations")
                .bean(checkEmployment, "getEmploymentDetails")
                .bean(checkEmployment, "getPayouts").bean(TransformComponent.class, "checkEmploymentReturnDTOToGeneralHttpResponse")
                .endRest();
    }
}
