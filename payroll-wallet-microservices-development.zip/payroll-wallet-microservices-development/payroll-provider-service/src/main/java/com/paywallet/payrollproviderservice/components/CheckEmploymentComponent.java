package com.paywallet.payrollproviderservice.components;

import static com.paywallet.core.states.constants.AppConstants.ERROR;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.camel.Body;
import org.apache.camel.ExchangeProperty;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.models.CheckEmploymentDTO;
import com.paywallet.core.states.models.CheckEmploymentReturnDTO;
import com.paywallet.core.states.models.EmployersDTO;
import com.paywallet.core.states.models.EmploymentInfoDTO;
import com.paywallet.payrollproviderservice.entities.ArgyleAccounts;
import com.paywallet.payrollproviderservice.services.ArgyleService;
import com.paywallet.payrollproviderservice.services.ArgyleUtilityService;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class CheckEmploymentComponent {

	public static final String COUNT = "count";
	public static final String RESULTS = "results";

	@Autowired
	ArgyleService argyleService;

	@Autowired
	ArgyleUtilityService argyleUtilityComponent;

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
	DateFormat outputDateFormat = new SimpleDateFormat("dd/MM/yyyy");

	public CheckEmploymentReturnDTO getPayAllocations(@Body ArgyleAccounts user,
			@ExchangeProperty(value = "checkEmploymentDTO") CheckEmploymentDTO checkEmploymentDTO) {
		if (user == null)
			throw new GeneralHttpException(ERROR, "No payroll data found for the given ID");
		JSONObject payAllocData = argyleUtilityComponent.getPayAllocationByAccountId(user.getAccountId());
		CheckEmploymentReturnDTO checkEmploymentReturnDTO = new CheckEmploymentReturnDTO();
		EmploymentInfoDTO employmentInfo = new EmploymentInfoDTO();
		Set<EmployersDTO> employersInfo = new HashSet<>();
		boolean remainderFound = false;
		if (payAllocData.getInt(COUNT) > 0) {
			JSONArray results = payAllocData.getJSONArray(RESULTS);
			for (int idx = 0; idx < results.length(); idx++) {
				JSONObject allocItem = results.optJSONObject(idx);
				if (allocItem != null && allocItem.has("allocation_value")
						&& allocItem.getString("allocation_value").equals("remainder")) {
					JSONObject bankDetails = allocItem.getJSONObject("bank_account");
					employmentInfo.setABANumForSalary(bankDetails.getString("routing_number"));
					employmentInfo.setAcctNumForSalary(bankDetails.getString("account_number"));
					EmployersDTO employerInfo = new EmployersDTO();
					employerInfo.setEmploymentInfo(employmentInfo);
					employerInfo.setEmployer(allocItem.getString("employer"));
					employerInfo.setPeriodToCover(checkEmploymentDTO.getPeriodToCover());
					employerInfo.setLabel("null");
					employerInfo.setType("string");
					employerInfo.setId(user.getPayrollId());
					employersInfo.add(employerInfo);
					remainderFound = true;
				}
			}
			if (!remainderFound) {
				EmployersDTO employerInfo = new EmployersDTO();
				employerInfo.setEmploymentInfo(employmentInfo);
				employerInfo.setPeriodToCover(checkEmploymentDTO.getPeriodToCover());
				employerInfo.setLabel("null");
				employerInfo.setEmployer(results.getJSONObject(0).getString("employer"));
				employerInfo.setType("string");
				employerInfo.setId(user.getPayrollId());
				employersInfo.add(employerInfo);
			}
			checkEmploymentReturnDTO.setEmployers(employersInfo);
			checkEmploymentReturnDTO.setEnquiryStatus("ENQUIRY_SUCCESS");
		}
		return checkEmploymentReturnDTO;
	}

	public CheckEmploymentReturnDTO getEmploymentDetails(@Body CheckEmploymentReturnDTO checkEmploymentReturnDTO,
			@ExchangeProperty(value = "argyleUserDetailsFromDB") ArgyleAccounts user) {
		JSONObject employmentData = argyleUtilityComponent.getEmploymentsByAccountId(user.getAccountId());
		if (employmentData.getInt(COUNT) > 0) {
			JSONArray results = employmentData.getJSONArray(RESULTS);
			JSONObject employment = results.getJSONObject(0);
			Set<EmployersDTO> employerInfo = checkEmploymentReturnDTO.getEmployers();
			EmployersDTO employerDTO = employerInfo.iterator().next();
			EmploymentInfoDTO employmentInfo = employerDTO.getEmploymentInfo();

			try {
				Date date = dateFormat.parse(employment.getString("hire_datetime"));
				employmentInfo.setDateOfHire(outputDateFormat.format(date));
			} catch (JSONException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			employmentInfo.setEmploymentStatus(employment.getString("status"));
			employmentInfo.setSalaryFrequency(employment.optString("pay_cycle"));
		}
		return checkEmploymentReturnDTO;
	}

	public CheckEmploymentReturnDTO getPayouts(@Body CheckEmploymentReturnDTO checkEmploymentReturnDTO,
			@ExchangeProperty(value = "argyleUserDetailsFromDB") ArgyleAccounts user) {
		Date date = new Date();
		String toDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		Set<EmployersDTO> employerInfo = checkEmploymentReturnDTO.getEmployers();
		EmployersDTO employerDTO = employerInfo.iterator().next();
		EmploymentInfoDTO employmentInfo = employerDTO.getEmploymentInfo();
		int period = 12;
		try {
			period = Integer.parseInt(employerDTO.getPeriodToCover().trim().split("\\s+")[0]);
		} catch (NumberFormatException ex) {
			throw new NumberFormatException("Period to Cover should contain the number of months. Eg., 12 months");
		}
		String fromDate = LocalDate.parse(toDate, DateTimeFormatter.ofPattern("uuuu-M-d")).plusMonths(-1 * period)
				.toString();
		// toDate is today, and fromDate is 'period' months back of today
		JSONObject payoutDataFromAPI = argyleUtilityComponent.getPayouts(user.getAccountId(), fromDate, toDate);
		if (payoutDataFromAPI.getInt(COUNT) > 0) {
			JSONArray payouts = payoutDataFromAPI.getJSONArray(RESULTS);
			List<Double> netPay = new ArrayList<>();
			List<Long> differenceInDays = new ArrayList<>();
			for (int i = 0; i < payouts.length(); i++) {
				JSONObject payout = payouts.getJSONObject(i);
				Double netPayFori = payout.getDouble("gross_pay");
				String startDateString = payout.getJSONObject("payout_period").optString("start_date");
				String endDateString = payout.getJSONObject("payout_period").optString("end_date");
				try {
					if (!startDateString.isBlank() && !endDateString.isBlank()) {
						startDateString = payout.getJSONObject("payout_period").optString("start_date");
						endDateString = payout.getJSONObject("payout_period").optString("end_date");
					} else if (payouts.getJSONObject(i + 1) != null) {
						endDateString = payout.getString("payout_date");
						startDateString = payouts.getJSONObject(i + 1).getString("payout_date");
					}
				} catch (JSONException ex) {
					startDateString = payout.getString("payout_date");
					endDateString = payouts.getJSONObject(i - 1).getString("payout_date");
				}
				try {
					Date startDate = dateFormat.parse(startDateString);
					Date endDate = dateFormat.parse(endDateString);
					differenceInDays.add(this.getDifferenceDays(startDate, endDate));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				netPay.add(netPayFori);
			}

			int estimatedCycleForAnnual = this.calculateCycleForAnnual(employmentInfo.getSalaryFrequency(),
					differenceInDays, employmentInfo);
			// pay_cycle : monthly, semimonthly, biweekly, weekly,
			Double totalPayment = netPay.stream().mapToDouble(Double::doubleValue).sum();
			Double averagePayPerPayPeriod = totalPayment / payoutDataFromAPI.getInt(COUNT);
			Double estimatedAnnualSalary = averagePayPerPayPeriod * estimatedCycleForAnnual;
			Double maxSalaryInPayPeriod = Collections.max(netPay);
			Double minSalaryInPayPeriod = Collections.min(netPay);

			String currency = payouts.getJSONObject(0).getString("currency") + " ";
			employmentInfo.setAveragePayPerPayPeriodForXMonths(currency + averagePayPerPayPeriod);
			employmentInfo.setMaxSalaryInPayPeriod(currency + maxSalaryInPayPeriod);
			employmentInfo.setMinSalaryInPayPeriod(currency + minSalaryInPayPeriod);
			employmentInfo.setEstimatedAnnualSalary(currency + estimatedAnnualSalary);
			log.info("netPay : " + netPay);
			log.info("totalPayment : " + totalPayment);
			log.info("number of payments in pay period : " + payoutDataFromAPI.getInt(COUNT));
			log.info("averagePayPerPayPeriod : " + averagePayPerPayPeriod);
			log.info("maxSalaryInPayPeriod : " + maxSalaryInPayPeriod);
			log.info("minSalaryInPayPeriod : " + minSalaryInPayPeriod);
			log.info("estimatedAnnualSalary : " + estimatedAnnualSalary);
		}
		return checkEmploymentReturnDTO;
	}

	private int calculateCycleForAnnual(String salaryFrequency, List<Long> differenceInDays,
			EmploymentInfoDTO employmentInfo) {
		log.info(differenceInDays);
		switch (salaryFrequency) {
			case "monthly":
				return 12;
			case "semimonthly":
				return 24;
			case "biweekly":
				return 26;
			case "weekly":
				return 52;
			default: {
				int differenceAv = differenceInDays.stream().mapToInt(Long::intValue).sum() / differenceInDays.size();
				log.info("differenceAv : " + differenceAv);
				String frequency = "";
				if (differenceAv < 7) {
					return 365 / differenceAv;
				} else if (differenceAv <= 7) {
					frequency = "weekly";
				} else if (differenceAv < 15) {
					frequency = "biweekly";
				} else if (differenceAv <= 21) {
					frequency = "semimonthly";
				} else {
					frequency = "monthly";
				}
				employmentInfo.setSalaryFrequency(frequency);
				return this.calculateCycleForAnnual(frequency, differenceInDays, employmentInfo);
			}
		}
	}

	public long getDifferenceDays(Date d1, Date d2) {
		long diff = d2.getTime() - d1.getTime();
		return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}

}
