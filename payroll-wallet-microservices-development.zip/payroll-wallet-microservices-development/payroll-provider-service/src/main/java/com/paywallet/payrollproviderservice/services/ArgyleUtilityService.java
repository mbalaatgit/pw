package com.paywallet.payrollproviderservice.services;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.paywallet.core.states.constants.AppConstants.ACCOUNT;
import static com.paywallet.core.states.constants.AppConstants.LIMIT;
import static com.paywallet.core.states.constants.AppConstants.OFFSET;
import static com.paywallet.core.states.constants.AppConstants.RESULTS;
import static com.paywallet.core.states.constants.AppConstants.USER;

import java.text.DecimalFormat;

import com.paywallet.payrollproviderservice.enumerations.ArgyleExceptionTypeEnum;
import com.paywallet.payrollproviderservice.exceptions.ArgyleAPIException;
import com.paywallet.payrollproviderservice.models.ArgyleCredentialsModel;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ArgyleUtilityService {
    @Value("${argyle.base}")
    private String argyleBasePath;

    @Value("${argyle.token}")
    private String argyleToken;

    @Value("${aggregator.service}")
    private String serviceName;

    @Value("${fineract.customer.routingNumber}")
    private String customerRoutingNumber;

    @Value("${argyle.link.base}")
    private String argyleLinkBasePath;

    @Autowired
    private RestTemplate restTemplate;

    private static final String ACCOUNT_TYPE = "account_type";
    private static final String ROUTING_NUMBER = "routing_number";
    private static final String ACCOUNT_NUMBER = "account_number";
    private static final String BANK_ACCOUNT = "bank_account";
    private static final String BANK_NAME = "bank_name";
    private static final String ACOUNTS = "accounts";

    private DecimalFormat df = new DecimalFormat("#.##");

    public JSONObject getUserTokenById(String user) throws ArgyleAPIException {
        JSONObject requestJson = new JSONObject();
        requestJson.put("user", user);
        return postAPI("user-tokens", requestJson);
    }

    public String encrypt(String accountNumber, double amount) throws ArgyleAPIException {
        String url = "pay-distribution-config/encrypt";
        JSONObject bankDetails = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        bankDetails.put(BANK_NAME, serviceName);
        bankDetails.put(ACCOUNT_TYPE, "checking");
        bankDetails.put(ROUTING_NUMBER, customerRoutingNumber);
        bankDetails.put(ACCOUNT_NUMBER, accountNumber);
        JSONObject allocation = new JSONObject();
        String totalAllocatedAmount = df.format(amount);
        allocation.put("value", totalAllocatedAmount);
        jsonObject.put("amount_allocation", allocation);
        jsonObject.put(BANK_ACCOUNT, bankDetails);
        JSONObject payDistributionEncrypt = this.postAPI(url, jsonObject);
        return payDistributionEncrypt.getString("encrypted_config");
    }

    public JSONObject getLinkItems() throws ArgyleAPIException {
        String url = "link-items?" + OFFSET + "=0&" + LIMIT + "=20000";
        return getAPI(url, false);
    }

    public JSONObject getLinkItemsByEmployer(String argyleEmployer) throws ArgyleAPIException {
        String url = "link-items?category=company&id_in=" + argyleEmployer + "&pd_support=true&limit=15";
        return this.getAPI(url, true);
    }

    public JSONObject getPayAllocationByUserId(String userId) throws ArgyleAPIException {
        String url = "pay-allocations?" + USER + "=" + userId;
        return getAPI(url, false);
    }

    public JSONObject getPayAllocationByAccountId(String accountId) throws ArgyleAPIException {
        String url = "pay-allocations?" + ACCOUNT + "=" + accountId;
        return getAPI(url, false);
    }

    public JSONObject getPayAllocationById(String payAllocationId) throws ArgyleAPIException {
        String url = "pay-allocations/" + payAllocationId;
        return getAPI(url, false);
    }

    public JSONObject getEmploymentsByAccountId(String accountId) throws ArgyleAPIException {
        String url = "employments?" + ACCOUNT + "=" + accountId;
        return getAPI(url, false);
    }

    public JSONObject getPayouts(String accountId, String startDate, String endDate) throws ArgyleAPIException {
        String url = "payouts?" + ACCOUNT + "=" + accountId + "&from_start_date=" + startDate + "&to_start_date=" + endDate;
        return getAPI(url, false);
    }

    public JSONObject getProfiles(String userId, String accountId) throws ArgyleAPIException {
        String url = "profiles?" + USER + "=" + userId + "&" + OFFSET + "=0&" + LIMIT + "=9999";
        if (accountId != null) {
            url += "&" + ACCOUNT + "=" + accountId;
        }
        return this.getAPI(url, false);
    }

    public JSONObject getProfile(String profileId) throws ArgyleAPIException {
        String url = "profiles/" + profileId;
        return this.getAPI(url, false);
    }

    public JSONObject getAccounts(String userId) throws ArgyleAPIException {
        String url = "accounts?" + USER + "=" + userId + "&" + LIMIT + "=100";
        return this.getAPI(url, false);
    }

    public JSONObject getAccount(String accountId, String userId) throws ArgyleAPIException {
        String url = ACOUNTS + "/" + accountId + "?" + userId;
        return this.getAPI(url, false);
    }

    public JSONObject createUser() throws ArgyleAPIException {
        return this.postAPI("users", new JSONObject());
    }

    public JSONObject updatePayDistribution(String argyleAccountId, String payDistributionConfig, String token)
            throws ArgyleAPIException {
        JSONObject payDistConfig = new JSONObject();
        payDistConfig.put("pay_distribution_config", payDistributionConfig);
        return this.postLink("accounts/" + argyleAccountId + "/update_pd", payDistConfig, token);
    }

    // public JSONObject submitPayDistribution(Set<PayDistributionAllocationsDTO>
    // allocations,
    // String payDistributionConfig, String argyleAccountId, String token) throws
    // ArgyleAPIException {
    // JSONObject payDistConfig = new JSONObject();
    // payDistConfig.put("pay_distribution_config", payDistributionConfig);
    // Set<JSONObject> allocs = allocations.stream().map(allocation -> {
    // JSONObject retAlloc = new JSONObject(allocation);
    // JSONObject bankAcc = new JSONObject();
    // bankAcc.put(ROUTING_NUMBER, allocation.getBankAccount().getRoutingNumber());
    // bankAcc.put(ACCOUNT_TYPE, allocation.getBankAccount().getAccountType());
    // bankAcc.put(BANK_NAME, allocation.getBankAccount().getBankName());
    // bankAcc.put(ACCOUNT_NUMBER, allocation.getBankAccount().getAccountNumber());
    // retAlloc.put(BANK_ACCOUNT, bankAcc);
    // retAlloc.remove("bankAccount");
    // return retAlloc;
    // }).collect(Collectors.toSet());
    // payDistConfig.put("allocations", allocs);
    // log.info(payDistConfig);
    // return this.postLink("accounts/" + argyleAccountId + "/submit_pd",
    // payDistConfig, token);
    // }

    public JSONObject postToArgyleAccount(ArgyleCredentialsModel credentials, String argyleEmployer,
            String argyleUserID, String token) throws ArgyleAPIException {
        JSONObject accounts = new JSONObject();
        JSONObject creds = new JSONObject();
        accounts.put("user", argyleUserID);  
        creds.put("username", credentials.getUsername());
        creds.put("password", credentials.getPassword());

        accounts.put("credentials", creds);
        accounts.put("data_partner", argyleEmployer);
        String[] permissions = { "scan-historical-info", "scan-future-info", "scan-pay-distribution",
                "update-pay-distribution" };
        accounts.put("permissions", permissions);
        return postLink("accounts", accounts, token);
    }

    public JSONArray getPayDistributionsFromArgyle(String userId, String token) throws ArgyleAPIException {
        String url = "accounts?" + USER + "=" + userId + "&" + LIMIT + "=1000";
        return getLink(url, token).getJSONArray(RESULTS);
    }

    private JSONObject postAPI(String endpoint, JSONObject jsonObject) throws ArgyleAPIException {
        try {
            HttpEntity<String> requestEntity = new HttpEntity<>(jsonObject.toString(), getBasicAuthHeader());
            String result = restTemplate.postForObject(argyleBasePath + endpoint, requestEntity, String.class);
            return new JSONObject(result);
        } catch (JSONException err) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_RESPONSE_PARSE_FAIL);
        } catch (HttpClientErrorException ex) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_COMMUNICATION_ERROR);
        }
    }

    private JSONObject getAPI(String endpoint, boolean baseLink) throws ArgyleAPIException {
        try {
            HttpEntity<String> requestEntity = new HttpEntity<>(getBasicAuthHeader());
            String result = restTemplate.exchange((baseLink ? argyleLinkBasePath : argyleBasePath) + endpoint,
                    HttpMethod.GET, requestEntity, String.class).getBody();
            return new JSONObject(result);
        } catch (JSONException err) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_RESPONSE_PARSE_FAIL);
        } catch (HttpClientErrorException ex) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_COMMUNICATION_ERROR);
        }
    }

    private JSONObject postLink(String endpoint, JSONObject jsonObject, String token) throws ArgyleAPIException {
        try {
            HttpEntity<String> request = new HttpEntity<>(jsonObject.toString(), this.setBearerAuth(token));
            String result = this.restTemplate.postForObject(argyleLinkBasePath + endpoint, request, String.class);
            return new JSONObject(result);
        } catch (JSONException err) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_RESPONSE_PARSE_FAIL);
        } catch (HttpClientErrorException ex) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_COMMUNICATION_ERROR);
        }
    }

    private JSONObject getLink(String endpoint, String token) throws ArgyleAPIException {
        try {
            HttpEntity<String> requestEntity = new HttpEntity<>(setBearerAuth(token));
            String result = restTemplate
                    .exchange(argyleLinkBasePath + endpoint, HttpMethod.GET, requestEntity, String.class).getBody();
            return new JSONObject(result);
        } catch (JSONException err) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_RESPONSE_PARSE_FAIL);
        } catch (HttpClientErrorException ex) {
            throw new ArgyleAPIException(ArgyleExceptionTypeEnum.ARGYLE_COMMUNICATION_ERROR);
        }

    }

    private HttpHeaders getBasicAuthHeader() {
        byte[] plainCredsBytes = argyleToken.getBytes();
        byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
        String base64Creds = new String(base64CredsBytes);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Authorization", "Basic " + base64Creds);
        return headers;
    }

    private HttpHeaders setBearerAuth(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(token);
        headers.set("User-Agent", "PayWallet/0.0.1");
        return headers;
    }
}
