package com.paywallet.payrollproviderservice.routes;

import static com.paywallet.core.states.constants.AppConstants.ERROR;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.RuntimeCamelException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.bean.validator.BeanValidationException;
import org.apache.camel.component.mongodb.MongoDbConstants;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.util.json.JsonObject;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.mongodb.client.model.Filters;
import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.common.GeneralHttpResponse;
import com.paywallet.core.states.models.ProviderConnectRequestDTO;
import com.paywallet.payrollproviderservice.components.ArgyleConnectComponent;
import com.paywallet.payrollproviderservice.components.TransformComponent;
import com.paywallet.payrollproviderservice.entities.ArgyleEmployers;
import com.paywallet.payrollproviderservice.entities.Payroll;
import com.paywallet.payrollproviderservice.models.ArgyleStatusModel;
import com.paywallet.payrollproviderservice.models.ProviderReauthenticateRequestDTO;
import com.paywallet.payrollproviderservice.services.ArgyleService;
import com.paywallet.payrollproviderservice.services.PayrollService;

@Component
public class ProviderConnectRoute extends RouteBuilder {

	@Autowired
	private ArgyleConnectComponent argyleConnectComponent;

	@Autowired
	private ArgyleService argyleService;

	@Autowired
	private PayrollService payrollService;

	@Autowired
	private TransformComponent transformComponent;

	@Value("${argyle.employers.connection.uri}")
	private String argyleEmployersConnUrl;

	private static final String CHECK_CONN_STATUS = "direct:checkConnectionStatus";
	private static final String TRANSFORM_RESPONSE = "transformToConnectResponse(${body.payrollId})";
	private static final String EMPLOYER_ID = "employerId";

	@Override
	public void configure() throws Exception {

		restConfiguration().component("servlet").enableCORS(false).bindingMode(RestBindingMode.json)
				.clientRequestValidation(true);

		onException(GeneralHttpException.class, BeanValidationException.class, RuntimeCamelException.class,
				HttpClientErrorException.class, HttpServerErrorException.class).handled(true).process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						Throwable cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
						Message msg = exchange.getOut();
						msg.setHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON);
						msg.setHeader(Exchange.HTTP_RESPONSE_CODE, 200);

						JsonObject errorMessage = new JsonObject();
						errorMessage.put("message", cause.getMessage());
						errorMessage.put("error", true);
						msg.setBody(errorMessage);
					}
				});

		rest("/aggregator").post("/connect").type(ProviderConnectRequestDTO.class).outType(GeneralHttpResponse.class)
				.to("direct:argyleLogin").post("/reauthenticate").type(ProviderReauthenticateRequestDTO.class)
				.outType(GeneralHttpResponse.class).to("direct:argyleReauthenticate");

		from("direct:argyleLogin").process(exchange -> {
			String requestBody = exchange.getIn().getBody(String.class);
			if (requestBody == null || requestBody.equals("")) {
				throw new GeneralHttpException(ERROR, "Bad Request");
			}
		}).to("bean-validator://argyle-connect").setProperty("requestBody", body())
				.setHeader(MongoDbConstants.CRITERIA, new Expression() {
					@Override
					public <T> T evaluate(Exchange exchange, Class<T> type) {
						ProviderConnectRequestDTO requestDTO = (ProviderConnectRequestDTO) exchange.getIn().getBody();
						Bson equalToEmployerId = Filters.eq(EMPLOYER_ID, requestDTO.getEmployerId());
						return exchange.getContext().getTypeConverter().convertTo(type, equalToEmployerId);
					}
				}).to(argyleEmployersConnUrl + "&operation=findOneByQuery").log("Query returned: '${body}'")
				.bean(transformComponent, "employerFromDBToArgyleEmployerDto")
				.setProperty("argyleEmployer", body()).bean(payrollService, "checkPayrollData").choice()
				.when(simple("${body} != null && ${body.payrollId} != null"))
				.bean(transformComponent, TRANSFORM_RESPONSE).endChoice().otherwise()
				.choice().when(simple("${exchangeProperty.requestBody.ignorePdStatus} == false"))
				.bean(argyleConnectComponent, "getLinkItems").bean(argyleConnectComponent, "checkPayrollLogin").end()
				.bean(argyleConnectComponent, "getArgyleToken")
				.bean(transformComponent, "transformToArgyleAccountCreationModel")
				.bean(argyleConnectComponent, "argyleConnect").setProperty("argyleData", body())
				.setProperty("counter", simple("0")).setProperty("operation", simple("saveData")).to(CHECK_CONN_STATUS);

		from("direct:argyleReauthenticate").process(exchange -> {
			String requestBody = exchange.getIn().getBody(String.class);
			if (requestBody == null || requestBody.equals("")) {
				throw new GeneralHttpException(ERROR, "Bad Request");
			}
		}).to("bean-validator://argyle-reconnect").setProperty("requestBody", body())
				.bean(payrollService, "checkPayrollUsername").choice()
				.when(simple("${exchangeProperty.requestBody.username} == ${body.username}"))
				.setHeader(MongoDbConstants.CRITERIA, new Expression() {
					@Override
					public <T> T evaluate(Exchange exchange, Class<T> type) {
						Payroll requestDTO = (Payroll) exchange.getIn().getBody();
						Bson equalToEmployerId = Filters.eq(EMPLOYER_ID, requestDTO.getEmployer());
						return exchange.getContext().getTypeConverter().convertTo(type, equalToEmployerId);
					}
				}).to(argyleEmployersConnUrl + "&operation=findOneByQuery").log("Query returned: '${body}'")
				.bean(transformComponent, "employerFromDBToArgyleEmployerDto")
				.setProperty("argyleEmployer", body()).bean(argyleConnectComponent, "getArgyleToken")
				.bean(transformComponent, "transformToArgyleAccountUpdationModel")
				.bean(argyleConnectComponent, "argyleConnect").setProperty("argyleData", body())
				.setProperty("counter", simple("0")).setProperty("operation", simple("updateData"))
				.to(CHECK_CONN_STATUS).otherwise().process(exchange -> {
					throw new GeneralHttpException(ERROR, "Username doesn't match with the given payroll ID");
				}).endRest();

		from(CHECK_CONN_STATUS).bean(argyleConnectComponent, "getConnectionStatus").choice()
				.when(simple("${body.status} == 'done'")).choice()
				.when(simple("${exchangeProperty.operation} == 'saveData'")).to("direct:saveData").otherwise()
				.to("direct:updateData").endChoice()
				.when(simple(
						"${body.status} == 'pending' || ${body.status} == 'authenticating' || ${body.status} == 'extracting_data'"))
				.delay(3000).to(CHECK_CONN_STATUS).endChoice().otherwise().process(exchange -> {
					ArgyleStatusModel requestBody = exchange.getIn().getBody(ArgyleStatusModel.class);
					throw new GeneralHttpException(ERROR, requestBody.getErrorCode());
				}).endRest();

		from("direct:saveData").bean(payrollService, "savePayrollData").bean(argyleService, "saveArgyleAccounts")
				.bean(argyleService, "saveArgyleCredentials")
				.bean(transformComponent, TRANSFORM_RESPONSE).endRest();

		from("direct:updateData").bean(payrollService, "updatePayrollData").bean(argyleService, "updateArgyleAccounts")
				.bean(argyleService, "updateArgyleCredentials")
				.bean(transformComponent, TRANSFORM_RESPONSE).endRest();
	}
}
