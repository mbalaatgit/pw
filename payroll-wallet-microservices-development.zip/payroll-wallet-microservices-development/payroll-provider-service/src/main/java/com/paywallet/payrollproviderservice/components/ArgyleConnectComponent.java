package com.paywallet.payrollproviderservice.components;

import static com.paywallet.core.states.constants.AppConstants.ERROR;
import static com.paywallet.core.states.constants.AppConstants.RESULTS;

import java.util.Optional;
import java.util.Set;

import org.apache.camel.Body;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperty;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.payrollproviderservice.entities.ArgyleEmployers;
import com.paywallet.payrollproviderservice.exceptions.ArgyleAPIException;
import com.paywallet.payrollproviderservice.models.ArgyleAccountCreationModel;
import com.paywallet.payrollproviderservice.models.ArgyleStatusModel;
import com.paywallet.payrollproviderservice.models.PayrollLoginInputDTO;
import com.paywallet.payrollproviderservice.services.ArgyleUtilityService;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class ArgyleConnectComponent {

    @Autowired
    ArgyleUtilityService argyleUtilityComponent;

    public JSONObject getLinkItems(@ExchangeProperty(value = "argyleEmployer") ArgyleEmployers argyleEmployer) {
        try {
            return this.argyleUtilityComponent.getLinkItemsByEmployer(argyleEmployer.getProviderId());
        } catch (ArgyleAPIException ex) {
            throw new GeneralHttpException(ERROR, ex.getMessage());
        }
    }

    public boolean checkPayrollLogin(@Body JSONObject linkItems) {
        if (linkItems.getInt("count") >= 1) {
            JSONObject linkItem = linkItems.getJSONArray(RESULTS).getJSONObject(0);
            JSONObject payDistWrite = linkItem.getJSONObject("features").optJSONObject("pay_distribution_write");
            if (payDistWrite != null && payDistWrite.getBoolean("supported")) {
                boolean flag = this.checkSplitTypes(payDistWrite.getJSONArray("split_types"));
                if (flag) {
                    if (this.checkAuthRequirements(linkItem)) {
                        throw new GeneralHttpException(ERROR, "Additional auth field functionality not implemented");
                    } else {
                        return true;
                    }
                } else {
                    throw new GeneralHttpException(ERROR, "Amount Pay Distribution Not Supported");
                }
            } else {
                throw new GeneralHttpException(ERROR, "Pay Distribution Write Not Supported");
            }
        } else {
            throw new GeneralHttpException(ERROR, "No link items for the argyle employer");
        }
    }

    public JSONObject getArgyleToken() {
        Optional<JSONObject> argyleUser = createArgyleUser();
        if (argyleUser.isEmpty()) {
            throw new GeneralHttpException(ERROR, "Failed to create argyle user");
        }
        return argyleUser.get();
    }

    public ArgyleAccountCreationModel argyleConnect(@Body PayrollLoginInputDTO payrollLoginInputDTO) {
        JSONObject res = new JSONObject();
        log.info(payrollLoginInputDTO);
        try {
            res = argyleUtilityComponent.postToArgyleAccount(payrollLoginInputDTO.getCredentials(),
                    payrollLoginInputDTO.getArgyleEmployer(), payrollLoginInputDTO.getArgyleUserID(),
                    payrollLoginInputDTO.getToken());
        } catch (ArgyleAPIException ex) {
            throw new GeneralHttpException(ERROR, ex.getMessage());
        }
        return new ArgyleAccountCreationModel(res.getString("data_partner"), res.getString("user"), res.getString("id"),
                res.optString("mfa_type"), res.optString("mfa_message"), payrollLoginInputDTO.getToken());
    }

    public ArgyleStatusModel getConnectionStatus(
            @ExchangeProperty(value = "argyleData") ArgyleAccountCreationModel agyleUser, Exchange exchange) {
        int currentCounter = Integer.parseInt(exchange.getProperty("counter").toString());
        ArgyleStatusModel status = new ArgyleStatusModel();
        if (currentCounter < 5) {
            JSONObject accountDetails = this.argyleUtilityComponent.getAccount(agyleUser.getAccountId(),
                    agyleUser.getUserId());
            if (accountDetails.optString("status").equals("awaiting_mfa")) {
                throw new GeneralHttpException(ERROR, "MFA not implemented");
            }
            if (accountDetails != null) {
                status.setStatus(accountDetails.optString("status"));
                status.setErrorCode(accountDetails.optString("error_code"));
                exchange.setProperty("counter", currentCounter + 1);
            }
        } else {
            status.setErrorCode("timeout_error");
        }
        return status;
    }

    private boolean checkSplitTypes(JSONArray splitTypes) {
        boolean flag = false;
        for (int i = 0; i < splitTypes.length(); i++) {
            if (splitTypes.getString(i).equals("amount")) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    private boolean checkAuthRequirements(JSONObject linkItem) {
        if (linkItem.has("auth_requirements")) {
            Set<String> authReqKeys = linkItem.getJSONObject("auth_requirements").keySet();
            return (authReqKeys.contains("username") && authReqKeys.contains("password") && authReqKeys.size() > 2);
        } else {
            return false;
        }
    }

    private Optional<JSONObject> createArgyleUser() {
        try {
            return Optional.ofNullable(this.argyleUtilityComponent.createUser());
        } catch (ArgyleAPIException ex) {
            throw new GeneralHttpException(ERROR, ex.getMessage());
        }
    }
}
