package com.paywallet.payrollproviderservice.enumerations;

public enum ArgyleExceptionTypeEnum {
	ARGYLE_RESPONSE_PARSE_FAIL(Values.ARGYLE_RESPONSE_PARSE_FAIL),
	ARGYLE_COMMUNICATION_ERROR(Values.ARGYLE_COMMUNICATION_ERROR);

	private String type;

	private ArgyleExceptionTypeEnum(String val) {
		this.type = val;
	}

	public static class Values {
		public static final String ARGYLE_RESPONSE_PARSE_FAIL = "Argyle response parsing failed !";
		public static final String ARGYLE_COMMUNICATION_ERROR = "Error while communicating with Argyle API.";
	}

	public String getType() {
		return this.type;
	}
}
