package com.paywallet.payrollproviderservice.exceptions;

import com.paywallet.payrollproviderservice.enumerations.ArgyleExceptionTypeEnum;

public class ArgyleAPIException extends RuntimeException {

    private static final long serialVersionUID = -2280452961650703605L;

    public ArgyleAPIException(ArgyleExceptionTypeEnum type) {
        super(type.getType());
    }
}