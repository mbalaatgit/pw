package com.paywallet.payrollproviderservice.repositories;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.paywallet.payrollproviderservice.entities.Payroll;

@Repository
public interface PayrollRepository extends MongoRepository<Payroll, String> {
	
	Optional<Payroll> findByUsernameAndEmployer(String username, String employer);
	Optional<Payroll> findByPayrollId(String payrollId);
}