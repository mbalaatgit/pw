package com.paywallet.payrollproviderservice.services;

import static com.paywallet.core.states.constants.AppConstants.ERROR;

import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;

import org.apache.camel.Body;
import org.apache.camel.ExchangeProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.paywallet.core.states.common.GeneralHttpException;
import com.paywallet.core.states.models.ProviderConnectRequestDTO;
import com.paywallet.core.states.models.CheckEmploymentDTO;
import com.paywallet.payrollproviderservice.entities.ArgyleAccounts;
import com.paywallet.payrollproviderservice.entities.ArgyleCredentials;
import com.paywallet.payrollproviderservice.entities.ArgyleUser;
import com.paywallet.payrollproviderservice.entities.Payroll;
import com.paywallet.payrollproviderservice.models.ArgyleAccountCreationModel;
import com.paywallet.payrollproviderservice.models.ProviderReauthenticateRequestDTO;
import com.paywallet.payrollproviderservice.repositories.ArgyleAccountsRepo;
import com.paywallet.payrollproviderservice.repositories.ArgyleCredentialsRepo;
import com.paywallet.payrollproviderservice.repositories.ArgyleUserRepository;

@Service
public class ArgyleService {

	@Autowired
	private ArgyleUserRepository argyleUserRepository;

	@Autowired
	private ArgyleAccountsRepo argyleAccountsRepo;

	@Autowired
	private ArgyleCredentialsRepo argyleCredentialsRepo;

	public ArgyleUser saveArgyleUserDetails(@ExchangeProperty(value = "requestBody") ProviderConnectRequestDTO requestDTO,
			@Body ArgyleAccountCreationModel creationModel) {

		Optional<ArgyleUser> argyleUser = argyleUserRepository.findByUsernameAndEmployerId(requestDTO.getUsername(),
				requestDTO.getEmployerId());
		ArgyleUser user = null;
		if (argyleUser.isPresent()) {
			user = argyleUser.get();
		} else {
			user = new ArgyleUser();
			user.setId(UUID.randomUUID().toString());
			user.setUsername(requestDTO.getUsername());
			user.setEmployerId(requestDTO.getEmployerId());
		}
		user.setPassword(new BCryptPasswordEncoder().encode(requestDTO.getPassword()));
		user.setArgyleUserId(creationModel.getUserId());
		user.setArgyleAccountId(creationModel.getAccountId());
		user.setToken(creationModel.getToken());
		argyleUserRepository.save(user);
		return user;
	}

	public ArgyleAccounts saveArgyleAccounts(
			@ExchangeProperty(value = "argyleData") ArgyleAccountCreationModel argyleData, @Body Payroll payrollData) {
		ArgyleAccounts account = new ArgyleAccounts();
		account.setId(UUID.randomUUID());
		account.setAccountId(argyleData.getAccountId());
		account.setUserId(argyleData.getUserId());
		account.setPayrollId(payrollData.getPayrollId());
		account.setPayAllocationId(null);
		try {
			argyleAccountsRepo.save(account);
		} catch (DuplicateKeyException e) {
			throw new GeneralHttpException(ERROR,
					"An argyle account with this account id is already created for the user");
		}
		return account;
	}

	public ArgyleAccounts updateArgyleAccounts(
			@ExchangeProperty(value = "argyleData") ArgyleAccountCreationModel argyleData, @Body Payroll payrollData) {
		Optional<ArgyleAccounts> argyleOptAccount = argyleAccountsRepo.findByPayrollId(payrollData.getPayrollId());
		ArgyleAccounts account = new ArgyleAccounts();
		if (argyleOptAccount.isPresent()) {
			account = argyleOptAccount.get();
			account.setAccountId(argyleData.getAccountId());
			account.setUserId(argyleData.getUserId());
			account.setPayAllocationId(null);
			argyleAccountsRepo.save(account);
		} else {
			throw new NoSuchElementException("No Provider Account found for the given Payroll ID");
		}
		return account;
	}

	public ArgyleCredentials saveArgyleCredentials(
			@ExchangeProperty(value = "requestBody") ProviderConnectRequestDTO requestBody,
			@Body ArgyleAccounts argyleAccounts) {
		ArgyleCredentials account = new ArgyleCredentials();
		account.setPayrollId(argyleAccounts.getPayrollId());
		account.setUsername(requestBody.getUsername());
		account.setPassword(requestBody.getPassword());
		argyleCredentialsRepo.save(account);
		return account;
	}

	public ArgyleCredentials updateArgyleCredentials(
			@ExchangeProperty(value = "requestBody") ProviderReauthenticateRequestDTO requestBody) {
		ArgyleCredentials account = new ArgyleCredentials();
		Optional<ArgyleCredentials> argyleOptAccount = argyleCredentialsRepo
				.findByPayrollId(requestBody.getPayrollId());
		if (argyleOptAccount.isPresent()) {
			account = argyleOptAccount.get();
			account.setPassword(requestBody.getPassword());
			argyleCredentialsRepo.save(account);
		} else {
			throw new NoSuchElementException("No Provider Credentials found for the given Payroll ID");
		}
		return account;
	}

	public ArgyleUser getByPayrollId(@Body CheckEmploymentDTO dto) {
		Optional<ArgyleUser> argyleUser = argyleUserRepository.findById(dto.getPayrollId());
		if (!argyleUser.isPresent()) {
			return null;
		}
		return argyleUser.get();
	}

	public ArgyleAccounts getArgyleUserData(@Body CheckEmploymentDTO dto) {
		Optional<ArgyleAccounts> argyleUser = argyleAccountsRepo.findByPayrollId(dto.getPayrollId());
		if (!argyleUser.isPresent()) {
			return null;
		}
		return argyleUser.get();
	}

	public ArgyleAccounts getArgyleUserDataById(String payrollId) {
		Optional<ArgyleAccounts> argyleUser = argyleAccountsRepo.findByPayrollId(payrollId);
		if (!argyleUser.isPresent()) {
			return null;
		}
		return argyleUser.get();
	}
}
