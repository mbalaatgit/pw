package com.paywallet.payrollproviderservice.models;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PayrollLoginInputDTO {
    private ArgyleCredentialsModel credentials;
    private String argyleEmployer;
    private String argyleUserID;
    private String token;
}

	