package com.paywallet.payrollproviderservice.entities;

import lombok.Data;

@Data
public class ArgyleEmployers {
	private String id;
	private String employerId;
	private String providerId;
}
