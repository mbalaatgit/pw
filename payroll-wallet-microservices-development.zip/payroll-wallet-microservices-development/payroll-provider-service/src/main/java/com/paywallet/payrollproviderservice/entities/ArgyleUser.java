package com.paywallet.payrollproviderservice.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document("ArgyleUser")
public class ArgyleUser {
	@Id
	private String id;
	private String username;
	private String password;
	private String argyleUserId;
	private String argyleAccountId;
	private String employerId;
	private String token;

}