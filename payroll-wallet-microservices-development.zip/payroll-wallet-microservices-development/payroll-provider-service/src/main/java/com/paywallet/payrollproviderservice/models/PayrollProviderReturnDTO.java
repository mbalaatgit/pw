package com.paywallet.payrollproviderservice.models;

import com.paywallet.payrollproviderservice.enumerations.PayrollProviderEnum;

import lombok.Data;

@Data
public class PayrollProviderReturnDTO {
	private String payrollId;
	private PayrollProviderEnum provider;
}
