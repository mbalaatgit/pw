package com.paywallet.payrollproviderservice.repositories;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.paywallet.payrollproviderservice.entities.ArgyleAccounts;
import com.paywallet.payrollproviderservice.entities.ArgyleCredentials;

@Repository
public interface ArgyleAccountsRepo extends MongoRepository<ArgyleAccounts, String> {
	public Optional<ArgyleAccounts> findByPayrollId(String payrollId);
}