package com.paywallet.payrollproviderservice.entities;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paywallet.payrollproviderservice.enumerations.PayrollProviderEnum;

import lombok.Data;
@Data
@Document("Payroll")
public class Payroll {
	@Id
	private String payrollId;
	private PayrollProviderEnum provider;
	private Date connectedOn;
	private String employer;
	private String username;
}
