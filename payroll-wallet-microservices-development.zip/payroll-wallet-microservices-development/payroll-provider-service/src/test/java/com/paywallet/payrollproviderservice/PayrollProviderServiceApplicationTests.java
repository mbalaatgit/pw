package com.paywallet.payrollproviderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayrollProviderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
